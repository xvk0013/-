% 打开本文件，点击 MATLAB 编辑器的“运行”，生成完整 Train / Test / Val。
% 每次运行自动创建新的输出目录；声学和配对参数见 src/cargo_v6_config.m。
% 首次运行自动重建录音级 Train/Test/Val 清单，后续运行复用该清单。
% 原始数据和输出位置统一在 v6_local_config.m 设置；ARR 保存在项目内复用。

v6_profile = 'full_dataset';  % 小规模配额可改为 'pilot'。

v6_project_dir = fileparts(mfilename('fullpath'));
addpath(v6_project_dir,fullfile(v6_project_dir,'src'),'-begin');
v6_run_id = char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'));
v6_output_dir = main_data_gen_v6('generate',v6_run_id,v6_profile);
