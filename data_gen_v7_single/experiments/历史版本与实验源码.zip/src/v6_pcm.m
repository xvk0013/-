function [record,passed]=v6_pcm(root,name,targets,slots,cfg,noise_clip,overlap,expected_band)
% Float32 WAVs with one fixed gain across all scenes, classes and splits.
if nargin<6, noise_clip=[]; end
if nargin<7, overlap=[]; end
if nargin<8, expected_band=''; end
refs=zeros(size(targets,1),3); refs(:,slots)=targets;
if isempty(slots), original=[noise_clip refs];
else, original=[sum(targets,2) refs]; end
peak=max(abs(original(:))); assert(isfinite(peak) && peak>0);
scale=cfg.output_gain; expected=original*scale;
folders=cfg.output_folders; assert(isequal(folders,{'mix','s1','s2','s3'}));
decoded=zeros(size(expected));
for k=1:numel(folders)
    dirpath=fullfile(root,folders{k}); if ~exist(dirpath,'dir'), mkdir(dirpath); end
    path=fullfile(dirpath,name);
    assert(exist(path,'file')==0,'V6:Overwrite','Output already exists: %s',path);
    audiowrite(path,single(expected(:,k)),cfg.target_fs,'BitsPerSample',cfg.output_bits);
    [wave,fs]=audioread(path); info=audioinfo(path);
    assert(fs==cfg.target_fs && info.BitsPerSample==cfg.output_bits && ...
        isequal(size(wave),[size(targets,1) 1]),'V6:PCM','Unexpected WAV format.');
    decoded(:,k)=wave;
end
% Use float32 spacing at the scene peak for the existing readback checks.
q=double(eps(single(max(abs(expected(:))))));
sample_error=max(abs(decoded(:)-expected(:)))/q;
background=zeros(size(targets,1),1);
if isempty(slots), background=expected(:,1); end
closure=max(abs(decoded(:,1)-sum(decoded(:,2:4),2)-background))/q;
inactive=setdiff(1:3,slots);
checks=[sample_error<=cfg.pcm.sample_error_ulp_max, ...
    closure<=cfg.pcm.closure_error_ulp_max, ...
    all(decoded(:,inactive+1)==0,'all'),all(any(decoded(:,slots+1)~=0,1)), ...
    all(isfinite(decoded(:)))];
labels={'samples','closure','inactive_channel','active_channel','finite'};
sir=struct('sir_db',NaN,'signed_sir_db',NaN,'sir_band','not_applicable', ...
    'energy1',NaN,'energy2',NaN,'stronger_source',NaN);
if numel(slots)==2
    sir=v6_sir_from_energy(sum(decoded(overlap,slots+1).^2,1),cfg);
    % Band membership of the drawn target card; 'any' records without gating.
    checks(end+1)=isempty(expected_band) || strcmp(expected_band,'any') || ...
        strcmp(sir.sir_band,expected_band); labels{end+1}='SIR';
end
passed=all(checks); failure='none'; if ~passed, failure=strjoin(labels(~checks),';'); end
record=struct('file_name',name,'passed',passed,'common_scale',scale, ...
    'mix_rms',sqrt(mean(decoded(:,1).^2)), ...
    'sample_error_ulp',sample_error,'closure_error_ulp',closure, ...
    'output_encoding',cfg.output_encoding,'failure',failure, ...
    'sir_db',sir.sir_db,'signed_sir_db',sir.signed_sir_db,'sir_band',sir.sir_band, ...
    'overlap_energy1',sir.energy1,'overlap_energy2',sir.energy2, ...
    'stronger_source',sir.stronger_source);
end
