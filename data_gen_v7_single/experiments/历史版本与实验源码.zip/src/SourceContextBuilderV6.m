classdef SourceContextBuilderV6 < handle
    % Genuine same-recording prehistory; frozen split membership is supplied
    % by v6_preflight / v6_prepare_sources. No synthetic history or new split draw.
    properties (SetAccess=private)
        Config
        Root
        RequestedSplits
        Checks=cell(0,11)
        Selection=cell(0,21)
        Index
        CachedPath=''
        CachedAudio=[]
        CachedHash=''
        CachedFs=nan
        CachedSamples=nan
        CachedResampleReport=struct()
        CachedResampleAsset=''
        ResamplerContexts=cell(0,12)
    end
    methods
        function obj=SourceContextBuilderV6(cfg,requested_splits)
            if nargin<2, requested_splits=cfg.split_types; end
            assert(all(ismember(requested_splits,cfg.split_types)));
            obj.Config=cfg;
            obj.RequestedSplits=requested_splits;
            obj.Root=fullfile(cfg.output_root,'source_contexts');
            assert(~exist(obj.Root,'dir'),'Context output exists; use a fresh output root.');
            mkdir(obj.Root);
            obj.Index=containers.Map('KeyType','char','ValueType','any');
        end

        function [q,asset]=prepare(obj,row,role)
            cfg=obj.Config; fs=cfg.target_fs;
            N=round(cfg.segment_len_s*fs); P=round(cfg.source_history_s*fs);
            k=str2double(row{6});
            assert(isfinite(k) && k>=1 && k==floor(k),'Invalid original segment index.');
            first=(k-1)*N+1; last=k*N;
            asset=struct();
            q=struct('status','PASS','reasons','none','sha256','unavailable', ...
                'peak',nan,'near_zero_s',nan,'near_zero_start_s',nan);
            if first-P<1
                q.status='REJECT'; q.reasons='MISSING_PREHISTORY';
                obj.log(row,role,'availability',q); return;
            end
            path=obj.resolve(row);
            if ~strcmp(path,obj.CachedPath)
                hash=sha256_file_v3(path);
                try
                    [raw,original_fs]=audioread(path);
                catch
                    q.status='REJECT'; q.reasons='RAW_DECODE_FAILED';
                    obj.log(row,role,'availability',q); return;
                end
                if isempty(raw) || any(~isfinite(raw(:)))
                    q.status='REJECT'; q.reasons='RAW_EMPTY_OR_NONFINITE';
                    obj.log(row,role,'availability',q); return;
                end
                original_samples=size(raw,1);
                [raw,resampler_report,b]=v6_prepare_recording(raw,original_fs,cfg);
                obj.CachedResampleReport=resampler_report;
                obj.CachedResampleAsset=fullfile(obj.Root,sprintf('ANTIALIAS_%dto%d.mat',original_fs,fs));
                if ~exist(obj.CachedResampleAsset,'file')
                    filter_report=rmfield(resampler_report,'removed_record_dc');
                    save(obj.CachedResampleAsset,'b','filter_report');
                end
                assert(strcmp(hash,sha256_file_v3(path)),'Raw recording changed while reading.');
                obj.CachedPath=path; obj.CachedAudio=raw; obj.CachedHash=hash;
                obj.CachedFs=original_fs; obj.CachedSamples=original_samples;
            end
            if last>numel(obj.CachedAudio)
                q.status='ERROR'; q.reasons='RAW_SPAN_MISMATCH';
                obj.log(row,role,'availability',q); return;
            end
            x=obj.CachedAudio(first-P:last);
            % Inspect raw amplitude before equalizing the effective input core.
            parts={x(1:P),x(P+(1:N))}; names={'resampled_history','resampled_core'};
            q=obj.inspect_parts(row,role,parts,names,q);
            if ismember(q.status,{'REJECT','ERROR'}), return; end
            [x,normalization]=v6_normalize_input(x,P,cfg);
            root_file=java.io.File(cfg.raw_root); input_file=java.io.File(path);
            prefix=[char(root_file.getCanonicalPath()) filesep];
            canonical=char(input_file.getCanonicalPath());
            assert(startsWith(canonical,prefix,'IgnoreCase',true),'Raw input escaped configured root.');
            asset=struct('x',x,'raw_relative',canonical(numel(prefix)+1:end), ...
                'raw_hash',obj.CachedHash, ...
                'context_start',first-P,'core_start',first,'core_stop',last, ...
                'raw_fs',obj.CachedFs,'raw_samples',obj.CachedSamples);
            D=obj.CachedResampleReport.delay_output_samples;
            asset.resampler_boundary_free=(first-P>D && last<=numel(obj.CachedAudio)-D);
            asset.resampler_delay_output_samples=D;
            asset.resampler_asset_sha256=sha256_file_v3(obj.CachedResampleAsset);
            asset.input_gain=normalization.input_gain;
            asset.input_rms_before=normalization.input_rms_before;
            asset.input_rms_after=normalization.input_rms_after;
        end

        function q=materialize(obj,row,q,asset,core_path)
            cfg=obj.Config; fs=cfg.target_fs; P=round(cfg.source_history_s*fs);
            [~,stem]=fileparts(row{5});
            relative=fullfile(row{3},row{1},[stem '.mat']);
            context_path=fullfile(obj.Root,relative);
            folder=fileparts(context_path); if ~exist(folder,'dir'), mkdir(folder); end
            assert(~exist(context_path,'file') && ~exist(core_path,'file'),'Duplicate materialization.');
            x=asset.x;
            save(context_path,'x','fs','-v6');
            % Floating-point context and core use the exact same source samples.
            folder=fileparts(core_path); if ~exist(folder,'dir'), mkdir(folder); end
            core=x(P+1:end);
            save(core_path,'core','fs','-v6');
            q.sha256=sha256_file_v3(core_path);
            obj.Selection(end+1,:)={row{3},str2double(row{1}),row{4},row{5},str2double(row{6}), ...
                asset.raw_relative,asset.raw_hash,relative,sha256_file_v3(context_path), ...
                q.sha256,asset.context_start,asset.core_start,asset.core_stop,asset.core_stop, ...
                fs,P,numel(core),q.status,q.reasons,asset.raw_fs,asset.raw_samples};
            obj.ResamplerContexts(end+1,:)={row{3},str2double(row{1}),row{4},row{5}, ...
                asset.raw_fs,fs,asset.resampler_asset_sha256,asset.resampler_boundary_free, ...
                asset.input_gain,asset.input_rms_before,asset.input_rms_after,asset.resampler_delay_output_samples};
        end

        function flush(obj)
            write_tsv_v3(fullfile(obj.Root,'CONTEXT_CHECKS.tsv'), ...
                {'role','split','class_id','recording_key','segment_file','stage','status', ...
                'reasons','peak','near_zero_s','near_zero_start_s'},obj.Checks);
            write_tsv_v3(fullfile(obj.Root,'CONTEXT_MANIFEST.tsv'), ...
                {'split','class_id','recording_key','segment_file','segment_index', ...
                'raw_relative_path','raw_sha256', ...
                'context_relative_path','context_sha256','core_sha256', ...
                'context_start_sample','core_start_sample','core_stop_sample','context_stop_sample', ...
                'target_fs','prehistory_samples','core_samples','status','reasons','raw_fs','raw_samples'},obj.Selection);
            counts=cell(0,4);
            for si=1:numel(obj.RequestedSplits)
                s=obj.RequestedSplits{si};
                for id=obj.Config.class_ids
                    pool=strcmp(obj.Checks(:,2),s) & reshape(cell2mat(obj.Checks(:,3)),[],1)==id;
                    for stage=unique(obj.Checks(pool,6)).'
                        mask=pool & strcmp(obj.Checks(:,6),stage{1});
                        for status={'PASS','REVIEW','REJECT','ERROR'}
                            counts(end+1,:)={s,id,[stage{1} '_' status{1}], ...
                                sum(mask & strcmp(obj.Checks(:,7),status{1}))}; %#ok<AGROW>
                        end
                    end
                    counts(end+1,:)={s,id,'missing_prehistory',sum(pool & strcmp(obj.Checks(:,8),'MISSING_PREHISTORY'))}; %#ok<AGROW>
                    selected=strcmp(obj.Selection(:,1),s) & reshape(cell2mat(obj.Selection(:,2)),[],1)==id;
                    counts(end+1,:)={s,id,'selected_contexts',sum(selected)}; %#ok<AGROW>
                end
            end
            write_tsv_v3(fullfile(obj.Root,'CONTEXT_COUNTS.tsv'),{'split','class_id','metric','count'},counts);
            write_tsv_v3(fullfile(obj.Root,'RESAMPLER_CONTEXTS.tsv'), ...
                {'split','class_id','recording_key','segment_file','input_fs','output_fs', ...
                'filter_asset_sha256','record_boundary_free','input_gain','input_rms_before','input_rms_after','delay_output_samples'}, ...
                obj.ResamplerContexts);
            write_tsv_v3(fullfile(obj.Root,'FRONTEND_COUNTS.tsv'),{'metric','value'}, ...
                {'selected_contexts',size(obj.ResamplerContexts,1);'T1_executed',0; ...
                'post_resample_bandpass_applied',0;'source_SL_assigned',0; ...
                'background_separated',0;'antialias_method',obj.Config.resampler.method; ...
                'normalization',obj.Config.normalization.method; ...
                'normalization_scope',obj.Config.normalization.scope; ...
                'normalization_target_rms',obj.Config.normalization.target_rms; ...
                'context_storage','MAT_double'});
        end
    end
    methods (Access=private)
        function path=resolve(obj,row)
            class_id=row{1};
            if ~isKey(obj.Index,class_id)
                ci=obj.Config.class_ids==str2double(class_id);
                assert(nnz(ci)==1,'Unknown original-recording class.');
                root=fullfile(obj.Config.raw_root,obj.Config.class_names{ci});
                assert(exist(root,'dir')==7,'Missing original recordings required for real prehistory: %s',root);
                wavs=dir(fullfile(root,'**','*.wav'));
                map=containers.Map('KeyType','char','ValueType','any');
                for j=1:numel(wavs)
                    [~,parent]=fileparts(wavs(j).folder); [~,stem]=fileparts(wavs(j).name);
                    key=lower([parent '/' stem]); path=fullfile(wavs(j).folder,wavs(j).name);
                    if isKey(map,key), map(key)=[map(key) {path}]; else, map(key)={path}; end
                end
                obj.Index(class_id)=map;
            end
            map=obj.Index(class_id); key=lower(row{4});
            assert(isKey(map,key),'Missing raw recording for frozen provenance: %s',key);
            matches=map(key);
            assert(numel(matches)==1,'Ambiguous original recording key, refusing to guess: %s',key);
            path=matches{1};
        end

        function q=inspect_parts(obj,row,role,parts,names,q)
            for j=1:numel(parts)
                check=inspect_waveform_quality_v3(parts{j},obj.Config.target_fs,obj.Config,numel(parts{j}));
                obj.log(row,role,names{j},check);
                if ~strcmp(check.status,'PASS')
                    reason=[upper(names{j}) ':' check.reasons];
                    if strcmp(q.reasons,'none'), q.reasons=reason; else, q.reasons=[q.reasons ';' reason]; end
                    if ismember(check.status,{'REJECT','ERROR'}) || strcmp(q.status,'PASS'), q.status=check.status; end
                end
                if ismember(q.status,{'REJECT','ERROR'}), return; end
            end
        end

        function log(obj,row,role,stage,q)
            obj.Checks(end+1,:)={role,row{3},str2double(row{1}),row{4},row{5},stage, ...
                q.status,q.reasons,q.peak,q.near_zero_s,q.near_zero_start_s};
        end
    end
end
