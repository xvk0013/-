function [channel,metrics]=causal_channel_v3(H,fs,nfft,max_delay_s,task_band)
% Make the declared finite causal channel explicit. Frequency interpolation
% can create negative-time/late ringing: projection is a model approximation,
% NOT just FFT padding. Log its full energy and task-band complex error.
P=round(max_delay_s*fs); half=floor(nfft/2)+1;
assert(nfft>2*(P+1) && numel(H)==half && all(isfinite(H)));
H=H(:); H(1)=real(H(1));
if mod(nfft,2)==0
    H(end)=real(H(end)); full=[H;conj(H(end-1:-1:2))];
else
    full=[H;conj(H(end:-1:2))];
end
raw=real(ifft(full)); power=sum(raw.^2);
assert(isfinite(power) && power>0,'Empty/nonfinite channel response.');
h=raw(1:P+1);
assert(sum(h.^2)>0,'No causal channel energy within declared delay support.');
kept=fft(h,nfft); kept=kept(1:half);
freq=(0:half-1)'*fs/nfft; band=freq>=task_band(1) & freq<=task_band(2);
negative=sum(raw(half+1:end).^2)/power;
late=sum(raw(P+2:half).^2)/power;
task_error=sqrt(sum(abs(kept(band)-H(band)).^2)/max(sum(abs(H(band)).^2),realmin));
task_gain_db=10*log10(sum(abs(kept(band)).^2)/max(sum(abs(H(band)).^2),realmin));
metrics=[negative late negative+late task_error task_gain_db sum(h.^2)/power];
channel=struct('H',kept,'nfft',nfft,'memory_samples',P,'fs',fs);
% Do not renormalize the projected channel: it would conceal changed loss.
end
