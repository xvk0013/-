function [rows,header] = read_tsv_v3(path,ncols)
% Preserve numeric-looking filenames and IDs as text (no readtable inference).
lines=readlines(path,'Encoding','UTF-8');
lines=lines(strlength(strtrim(lines))>0);
assert(~isempty(lines),'Empty manifest: %s',path);
header=reshape(cellstr(split(lines(1),sprintf('\t'))),1,[]);
assert(numel(header)==ncols,'Wrong header width: %s',path);
rows=cell(numel(lines)-1,ncols);
for k=2:numel(lines)
    fields=reshape(cellstr(strtrim(split(lines(k),sprintf('\t')))),1,[]);
    assert(numel(fields)==ncols,'Wrong column count, row %d: %s',k,path);
    rows(k-1,:)=fields;
end
end
