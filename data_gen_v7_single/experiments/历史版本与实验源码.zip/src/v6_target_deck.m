function deck=v6_target_deck(cfg,requested,combo_name)
% Exact stratified target deck: primary_fraction of the cards draw inside the
% inset primary band, the rest inside the inset supplement band. Dealing by
% accepted-scene index makes the target-card split exact; L4 can change the
% realized waveform-band counts, which are reported separately.
n_primary=round(requested*cfg.pairing.primary_fraction);
n_supplement=requested-n_primary;
rng(v6_seed([cfg.active_split '|' combo_name '|deck'],cfg.physical_seed),'twister');
p=cfg.pairing.deck_primary_draw_db;
s=cfg.pairing.deck_supplement_draw_db;
target=[p(1)+(p(2)-p(1))*rand(1,n_primary),s(1)+(s(2)-s(1))*rand(1,n_supplement)];
band=[repmat({'primary'},1,n_primary),repmat({'supplement'},1,n_supplement)];
order=randperm(requested);
deck=struct('target_db',target(order),'band',{band(order)}, ...
    'n_primary',n_primary,'n_supplement',n_supplement);
end
