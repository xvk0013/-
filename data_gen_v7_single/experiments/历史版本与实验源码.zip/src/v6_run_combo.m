function [result,cache]=v6_run_combo(cfg,cache,k)
% Full-dataset generator; recording and clip uses commit only after PCM.
slots=cfg.combo_slots{k}; nt=numel(slots); requested=cfg.scene_counts(k);
name=cfg.combo_names{k}; folder=fullfile(cfg.dataset_root,cfg.combo_folders{k},cfg.active_split);
assert(~exist(folder,'dir'),'V6:OutputExists','Combination output already exists.'); mkdir(folder);
uses=zeros(1,numel(cache.recordings));
noise_uses=zeros(1,numel(cache.noise_recordings));
clip_uses=zeros(1,numel(cache.sources)); caps=cache.recording_caps(:,k).';
max_attempts=cfg.max_attempts_per_combination(k);
attempted=0; accepted=0; selected=struct([]); pcm=struct([]);
primary_count=0; supplement_count=0; outside_count=0; card_mismatch_count=0;
candidate_switch_total=0; keeper_redraw_total=0; deck=[];
[~,single_ranges]=ismember(cfg.single_ranges_km,cfg.ranges_km);
pair_state=struct();
if nt==2
    clip_caps=zeros(size(clip_uses));
    for recording=find(caps>0)
        group=cache.recordings(recording).source_indices;
        clip_caps(group)=max(cfg.pairing.minimum_clip_cap, ...
            ceil(cfg.pairing.clip_capacity_headroom*caps(recording)/numel(group)));
    end
    pair_state=struct('recording_uses',uses,'recording_caps',caps, ...
        'clip_uses',clip_uses,'clip_caps',clip_caps, ...
        'record_queues',{cell(1,2)},'clip_queues',{cell(1,numel(uses))}, ...
        'pair_uses',containers.Map('KeyType','char','ValueType','double'), ...
        'range_uses',zeros(1,numel(cfg.ranges_km)));
    assert(isfield(cache,'energy_table'),'V6:EnergyTable','Energy table missing for this split.');
    deck=v6_target_deck(cfg,requested,name);
end
template=struct('candidate_id','','attempt',0,'combination',name,'n_targets',nt, ...
    'source1_index',0,'source2_index',0,'recording1_index',0,'recording2_index',0, ...
    'recording1','none','recording2','none', ...
    'range1_km',NaN,'range2_km',NaN,'source_depth1_m',NaN,'source_depth2_m',NaN, ...
    'source1_x_km',NaN,'source2_x_km',NaN, ...
    'keeper_slot',NaN,'signed_offset_m',NaN,'separation_m',NaN,'direction','not_applicable', ...
    'sir_db',NaN,'sir_band','not_applicable','card_target_db',NaN,'card_band','none', ...
    'predicted_signed_db',NaN,'drift_db',NaN,'stronger_scheduled',NaN, ...
    'candidate_switches',NaN,'keeper_redraws',NaN, ...
    'ladder_level',NaN,'shortlist_size',NaN,'tolerance_db',NaN,'tolerance_miss',NaN, ...
    'pair_search_reason','not_applicable', ...
    'noise_recording_index',0,'noise_recording','none', ...
    'noise_start_sample',NaN,'noise_stop_sample',NaN,'noise_input_gain',NaN, ...
    'noise_input_rms_before',NaN,'noise_input_rms_after',NaN, ...
    'noise_receiver_target_rms',NaN,'noise_receiver_gain',NaN, ...
    'decision','failed_or_inflight');
candidates=repmat(template,max_attempts,1);
old=rng; guard=onCleanup(@() rng(old));
try
    while accepted<requested && attempted<max_attempts
        exhausted=false;
        for t=1:nt
            group=cache.groups{slots(t)};
            exhausted=exhausted || ~any(uses(group)<caps(group));
        end
        if exhausted, break; end
        attempted=attempted+1; id=sprintf('%s_%s_c%06d',cfg.active_split,name,attempted);
        c=template; c.candidate_id=id; c.attempt=attempted; candidates(attempted)=c;
        rng(v6_seed(id,cfg.physical_seed),'twister');
        indices=zeros(1,nt); recording_indices=zeros(1,nt); ranges=zeros(1,nt);
        depths=randi(numel(cfg.source_depths_m),1,nt);
        propagated=zeros(cfg.target_fs*cfg.segment_len_s,nt);
        noise_clip=[];
        overlap=[];
        if nt==2
            overlap=(1:cfg.target_fs*cfg.segment_len_s).';
        end
        rng(v6_seed([id '|sources'],cfg.physical_seed),'twister');
        if nt==0
            c.noise_recording_index=randi(numel(cache.noise_recordings));
            ambient=cache.noise_recordings(c.noise_recording_index);
            N=cfg.target_fs*cfg.segment_len_s;
            c.noise_recording=ambient.file;
            c.noise_start_sample=randi(numel(ambient.wave)-N+1);
            c.noise_stop_sample=c.noise_start_sample+N-1;
            noise_clip=ambient.wave(c.noise_start_sample:c.noise_stop_sample);
            [noise_clip,normalization]=v6_normalize_input(noise_clip,0,cfg);
            c.noise_input_gain=normalization.input_gain;
            c.noise_input_rms_before=normalization.input_rms_before;
            c.noise_input_rms_after=normalization.input_rms_after;
            levels=cache.noise_level_reference.log_rms_sorted;
            position=1+(numel(levels)-1)*rand;
            c.noise_receiver_target_rms=exp(interp1(1:numel(levels),levels,position,'linear'));
            c.noise_receiver_gain=c.noise_receiver_target_rms / ...
                (normalization.input_rms_after*cfg.output_gain);
            noise_clip=noise_clip*c.noise_receiver_gain;
        end
        if nt==1
            recording_indices=draw_recording(cache.groups{slots},uses,caps);
            indices=draw_clip(cache.recordings(recording_indices).source_indices,clip_uses);
            ranges=single_ranges(randi(numel(single_ranges)));
        elseif nt==2
            card_target=deck.target_db(accepted+1);
            card_band=deck.band{accepted+1};
            rng(v6_seed([id '|pairing'],cfg.physical_seed),'twister');
            stronger=randi(2); keeper=randi(2); matcher=3-keeper;
            target_signed=card_target*(3-2*stronger);
            c.card_target_db=card_target; c.card_band=card_band;
            c.stronger_scheduled=stronger; c.keeper_slot=keeper;
            pair_state.recording_uses=uses; pair_state.clip_uses=clip_uses;
            cand_switches=0; keeper_redraws=0; ladder_level=0;
            solved=false; rejected=false; card_mismatch=false; keeper_source=[];
            indices=zeros(1,2); ranges=zeros(1,2);
            predicted_signed=NaN; shortlist_size=NaN; tol_used=NaN; tolerance_miss=false;
            measured=struct('sir_db',NaN,'signed_sir_db',NaN,'sir_band','none', ...
                'energy1',NaN,'energy2',NaN,'stronger_source',NaN);
            while ~solved && ~rejected
                [scheduled,pair_state]=v6_schedule_pair(cfg,cache,slots,pair_state, ...
                    depths,keeper,target_signed,keeper_source);
                if ~scheduled.found
                    rejected=true;
                    c.pair_search_reason=scheduled.reason;
                else
                    keeper_source=scheduled.keeper_source;
                    cand_try=0;
                    % 每场景换位预算累计；重入后的新名单首位不计换位。
                    while ~solved && cand_try<size(scheduled.candidates,1) && ...
                            (cand_try==0 || cand_switches<cfg.pairing.candidate_switches_max)
                        cand_try=cand_try+1;
                        if cand_try>1
                            cand_switches=cand_switches+1;
                            ladder_level=max(ladder_level,2);
                        end
                        row=scheduled.candidates(cand_try,:);
                        indices(keeper)=scheduled.keeper_source;
                        ranges(keeper)=scheduled.keeper_range;
                        indices(matcher)=row(1); ranges(matcher)=row(2);
                        predicted_signed=row(3);
                        shortlist_size=scheduled.shortlist_size;
                        tol_used=scheduled.tolerance_db;
                        tolerance_miss=scheduled.tolerance_miss;
                        % The table and final WAV references use the same full
                        % 5-second samples and float32 conversion, without gating.
                        energies=[cache.energy_table(indices(1),ranges(1),depths(1)), ...
                            cache.energy_table(indices(2),ranges(2),depths(2))];
                        measured=v6_sir_from_energy(energies,cfg);
                        solved=strcmp(measured.sir_band,card_band);
                    end
                    if ~solved && keeper_redraws<cfg.pairing.keeper_redraws_max
                        keeper_redraws=keeper_redraws+1;
                        ladder_level=max(ladder_level,3);
                    elseif ~solved
                        card_mismatch=true; ladder_level=4; solved=true;
                    end
                end
            end
            if rejected
                c.decision='pairing_rejected'; candidates(attempted)=c; continue;
            end
            recording_indices=[cache.sources(indices).recording_index];
            c.signed_offset_m=round((cfg.ranges_km(ranges(matcher))- ...
                cfg.ranges_km(ranges(keeper)))*1000);
            c.separation_m=abs(c.signed_offset_m);
            c.direction='same_range';
            if c.signed_offset_m<0, c.direction='matcher_closer'; end
            if c.signed_offset_m>0, c.direction='matcher_farther'; end
            c.sir_db=measured.sir_db; c.sir_band=measured.sir_band;
            c.predicted_signed_db=predicted_signed;
            c.drift_db=measured.signed_sir_db-predicted_signed;
            c.candidate_switches=cand_switches;
            c.keeper_redraws=keeper_redraws; c.ladder_level=ladder_level;
            c.shortlist_size=shortlist_size; c.tolerance_db=tol_used;
            c.tolerance_miss=tolerance_miss;
            c.pair_search_reason='scheduled';
        end
        for t=1:nt
            assert(cache.sources(indices(t)).recording_index==recording_indices(t));
            row=cache.sources(indices(t)).row;
            c.(sprintf('source%d_index',t))=indices(t);
            c.(sprintf('recording%d_index',t))=recording_indices(t);
            c.(sprintf('recording%d',t))=row{4};
            c.(sprintf('range%d_km',t))=cfg.ranges_km(ranges(t));
            c.(sprintf('source%d_x_km',t))=cache.geometry.source_x_km(ranges(t));
            c.(sprintf('source_depth%d_m',t))=cfg.source_depths_m(depths(t));
            candidates(attempted)=c;
            [wave,cache]=v6_get_core(cfg,cache,indices(t),ranges(t),depths(t));
            propagated(:,t)=wave;
        end
        targets=propagated;
        if any(~isfinite(targets(:))) || any(~any(targets~=0,1))
            c.decision='numeric_rejected'; candidates(attempted)=c; continue;
        end
        candidates(attempted)=c;
        filename=sprintf('combined_%05d.wav',accepted+1);
        expected_band='';
        if nt==2
            expected_band=card_band;
            if card_mismatch, expected_band='any'; end
        end
        [p,passed]=v6_pcm(folder,filename,targets,slots,cfg,noise_clip,overlap,expected_band);
        if ~passed
            v6_json(fullfile(folder,'PCM_FAILURE.json'),p);
            error('V6:PCM','Write/readback failed: %s (%s). Stopping.',filename,p.failure);
        end
        entry=struct('candidate_id',id,'file_name',filename,'combination',name);
        entry.combIdx=accepted+1; entry.candidateIdx=attempted; entry.n_targets=nt;
        entry.split=cfg.active_split; entry.fs=cfg.target_fs;
        entry.band_lo_hz=0; entry.band_hi_hz=cfg.target_fs/2;
        entry.source1_index=c.source1_index; entry.source2_index=c.source2_index;
        entry.recording1_index=c.recording1_index; entry.recording2_index=c.recording2_index;
        entry.recording1=c.recording1; entry.recording2=c.recording2;
        entry.range1_km=c.range1_km; entry.range2_km=c.range2_km;
        entry.source1_x_km=c.source1_x_km; entry.source2_x_km=c.source2_x_km;
        entry.source_depth1_m=c.source_depth1_m; entry.source_depth2_m=c.source_depth2_m;
        entry.keeper_slot=c.keeper_slot; entry.signed_offset_m=c.signed_offset_m;
        entry.separation_m=c.separation_m; entry.direction=c.direction;
        entry.sir_db=p.sir_db; entry.signed_sir_db=p.signed_sir_db; entry.sir_band=p.sir_band;
        entry.overlap_energy1=p.overlap_energy1; entry.overlap_energy2=p.overlap_energy2;
        entry.stronger_source=p.stronger_source;
        entry.card_target_db=c.card_target_db; entry.card_band=c.card_band;
        entry.predicted_signed_db=c.predicted_signed_db; entry.drift_db=c.drift_db;
        entry.stronger_scheduled=c.stronger_scheduled;
        entry.candidate_switches=c.candidate_switches;
        entry.keeper_redraws=c.keeper_redraws; entry.ladder_level=c.ladder_level;
        entry.shortlist_size=c.shortlist_size; entry.tolerance_db=c.tolerance_db;
        entry.tolerance_miss=c.tolerance_miss;
        entry.pair_search_reason=c.pair_search_reason;
        entry.receiver_depth_m=NaN;
        entry.receiver_x_km=NaN;
        if nt>0
            entry.receiver_depth_m=cache.geometry.receiver_depth_m;
            entry.receiver_x_km=cache.geometry.receiver_x_km;
        end
        entry.class1='none'; entry.class2='none'; entry.class_id1=NaN; entry.class_id2=NaN;
        filenames={'none','none','none'};
        for t=1:nt
            entry.(sprintf('class%d',t))=cfg.class_names{slots(t)};
            entry.(sprintf('class_id%d',t))=cfg.class_ids(slots(t));
            filenames{slots(t)}=cache.sources(indices(t)).row{5};
        end
        entry.fileA=filenames{1}; entry.fileB=filenames{2}; entry.fileC=filenames{3};
        entry.label_Cargo=ismember(1,slots); entry.label_Tanker=ismember(2,slots); entry.label_Tug=ismember(3,slots);
        entry.overlap_start_s=0; entry.overlap_end_s=cfg.segment_len_s;
        entry.receiver_model=cfg.receiver_model;
        entry.source_normalization=cfg.normalization.method;
        entry.normalization_scope=cfg.normalization.scope;
        entry.normalization_target_rms=cfg.normalization.target_rms;
        entry.input_gain1=NaN; entry.input_rms_before1=NaN; entry.input_rms_after1=NaN;
        if nt>0
            entry.input_gain1=cache.sources(indices(1)).input_gain;
            entry.input_rms_before1=cache.sources(indices(1)).input_rms_before;
            entry.input_rms_after1=cache.sources(indices(1)).input_rms_after;
        end
        entry.input_gain2=NaN; entry.input_rms_before2=NaN; entry.input_rms_after2=NaN;
        if nt==2
            entry.input_gain2=cache.sources(indices(2)).input_gain;
            entry.input_rms_before2=cache.sources(indices(2)).input_rms_before;
            entry.input_rms_after2=cache.sources(indices(2)).input_rms_after;
        end
        entry.common_scale=p.common_scale;
        entry.mix_rms=p.mix_rms;
        entry.mixing_stage='receiver_after_independent_propagation';
        entry.noise_recording=c.noise_recording;
        entry.noise_recording_index=c.noise_recording_index;
        entry.noise_start_sample=c.noise_start_sample;
        entry.noise_stop_sample=c.noise_stop_sample;
        entry.noise_input_gain=c.noise_input_gain;
        entry.noise_input_rms_before=c.noise_input_rms_before;
        entry.noise_input_rms_after=c.noise_input_rms_after;
        entry.noise_receiver_target_rms=c.noise_receiver_target_rms;
        entry.noise_receiver_gain=c.noise_receiver_gain;
        if nt==0
            entry.mixing_stage='standalone_receiver_ambient_recording';
            entry.overlap_start_s=NaN; entry.overlap_end_s=NaN;
        end
        % Commit only after every component passes write/readback.
        if isempty(selected), selected=entry; pcm=p;
        else, selected(end+1,1)=entry; pcm(end+1,1)=p; end %#ok<AGROW>
        uses(recording_indices)=uses(recording_indices)+1;
        clip_uses(indices)=clip_uses(indices)+1;
        if nt==2
            key=sprintf('%d_%d',indices);
            if ~isKey(pair_state.pair_uses,key), pair_state.pair_uses(key)=0; end
            pair_state.pair_uses(key)=pair_state.pair_uses(key)+1;
            pair_state.range_uses(ranges(1))=pair_state.range_uses(ranges(1))+1;
            pair_state.range_uses(ranges(2))=pair_state.range_uses(ranges(2))+1;
            primary_count=primary_count+strcmp(p.sir_band,'primary');
            supplement_count=supplement_count+strcmp(p.sir_band,'supplement');
            outside_count=outside_count+strcmp(p.sir_band,'outside');
            card_mismatch_count=card_mismatch_count+card_mismatch;
            candidate_switch_total=candidate_switch_total+cand_switches;
            keeper_redraw_total=keeper_redraw_total+keeper_redraws;
            c.sir_db=p.sir_db; c.sir_band=p.sir_band;
        end
        if nt==0, noise_uses(c.noise_recording_index)=noise_uses(c.noise_recording_index)+1; end
        accepted=accepted+1; c.decision='accepted'; candidates(attempted)=c;
        if mod(accepted,cfg.progress_every_scenes)==0 || accepted==requested
            fprintf('%s/%s: accepted %d/%d from %d proposals.\n', ...
                cfg.active_split,name,accepted,requested,attempted);
        end
    end
    if accepted==requested
        stop_reason='quota_filled';
    elseif attempted>=max_attempts
        stop_reason='attempt_budget_exhausted';
    else
        stop_reason='source_capacity_exhausted';
    end
    result=finish(stop_reason);
catch err
    try
        finish('failed');
    catch report_error
        warning('V6:ReportFailure','%s',report_error.message);
    end
    rethrow(err);
end

    function out=finish(stop_reason)
        cset=candidates(1:attempted); decisions={cset.decision};
        stages={'numeric_rejected','pairing_rejected','failed_or_inflight','accepted'};
        stage_counts=zeros(1,numel(stages));
        for stage_index=1:numel(stages), stage_counts(stage_index)=sum(strcmp(decisions,stages{stage_index})); end
        assert(sum(stage_counts)==attempted && stage_counts(end)==accepted,'V6:CountClosure','Candidate counts do not close.');
        assert(accepted==numel(selected) && accepted==numel(pcm));
        assert(all(uses<=caps) && sum(uses)==nt*accepted,'V6:ReuseClosure','Accepted recording uses do not close.');
        by_recording=accumarray([cache.sources.recording_index].',clip_uses(:),[numel(uses) 1]).';
        assert(isequal(by_recording,uses),'V6:ReuseClosure','Clip and recording uses disagree.');
        for slot_loop=1:nt, assert(sum(uses(cache.groups{slots(slot_loop)}))==accepted); end
        usage=cell(0,7);
        for slot_loop=1:nt
            for recording_index=cache.groups{slots(slot_loop)}
                recording=cache.recordings(recording_index); cap=caps(recording_index);
                usage(end+1,:)={name,cfg.active_split,recording.class_name,recording.recording_key, ...
                    uses(recording_index),cap,cap-uses(recording_index)}; %#ok<AGROW>
            end
        end
        out=struct('combination',name,'n_targets',nt,'requested',requested,'accepted',accepted, ...
            'attempted',attempted,'shortage',requested-accepted,'stop_reason',stop_reason, ...
            'quota_filled',accepted==requested, ...
            'source_uses',clip_uses,'recording_uses',uses,'recording_caps',caps, ...
            'noise_recording_uses',noise_uses, ...
            'primary_sir_scenes',primary_count,'supplement_sir_scenes',supplement_count, ...
            'primary_fraction_actual',primary_count/max(accepted,1), ...
            'supplement_fraction_actual',supplement_count/max(accepted,1), ...
            'outside_sir_scenes',outside_count, ...
            'card_band_mismatch_scenes',card_mismatch_count, ...
            'candidate_switches_total',candidate_switch_total, ...
            'keeper_redraws_total',keeper_redraw_total, ...
            'used_recordings',nnz(uses),'used_clips',nnz(clip_uses), ...
            'source_usage_rows',{usage}, ...
            'selected',selected,'pcm',pcm,'count_closure',true);
        for stage_index=1:numel(stages)-1, out.(stages{stage_index})=stage_counts(stage_index); end
        v6_write_structs(fullfile(folder,'CANDIDATES.tsv'),cset);
        v6_write_structs(fullfile(folder,'SCENES.tsv'),selected);
        v6_write_structs(fullfile(folder,'all_info.txt'),selected);
        v6_write_structs(fullfile(folder,'PCM_READBACK.tsv'),pcm);
        v6_write_tsv(fullfile(folder,'SOURCE_REUSE.tsv'), ...
            {'combination','split','class_name','recording_key','accepted_uses','max_uses','remaining_capacity'},usage);
        if nt==2
            pair_keys=keys(pair_state.pair_uses); pair_rows=cell(numel(pair_keys),8);
            for j=1:numel(pair_keys)
                pair=sscanf(pair_keys{j},'%d_%d').'; a=cache.sources(pair(1)).row; b=cache.sources(pair(2)).row;
                pair_rows(j,:)={pair(1),pair(2),a{4},b{4},a{5},b{5}, ...
                    pair_state.pair_uses(pair_keys{j}),cfg.pairing.max_pair_uses};
            end
            v6_write_tsv(fullfile(folder,'PAIR_REUSE.tsv'), ...
                {'source1_index','source2_index','recording1','recording2','segment1','segment2','accepted_uses','max_uses'},pair_rows);
            group=find(pair_state.clip_caps>0); clip_rows=cell(numel(group),5);
            for j=1:numel(group)
                index=group(j); row=cache.sources(index).row;
                clip_rows(j,:)={row{2},row{4},row{5},clip_uses(index),pair_state.clip_caps(index)};
            end
            v6_write_tsv(fullfile(folder,'SOURCE_CLIP_USES.tsv'), ...
                {'class_name','recording_key','segment_file','accepted_uses','max_uses'},clip_rows);
            out.unique_pairs=numel(pair_keys);
        else
            out.unique_pairs=0;
        end
        if nt==0
            noise_rows=[{cache.noise_recordings.file}.' num2cell(noise_uses(:))];
            v6_write_tsv(fullfile(folder,'NOISE_SOURCE_USES.tsv'), ...
                {'file','accepted_uses'},noise_rows);
        end
        counts=[{'attempted',attempted};[stages(:) num2cell(stage_counts(:))]; ...
            {'source_instances_committed',sum(uses);'count_closure',true;'stop_reason',stop_reason; ...
            'primary_sir_scenes',primary_count;'supplement_sir_scenes',supplement_count; ...
            'outside_sir_scenes',outside_count;'card_band_mismatch_scenes',card_mismatch_count; ...
            'candidate_switches_total',candidate_switch_total;'keeper_redraws_total',keeper_redraw_total; ...
            'used_recordings',out.used_recordings;'used_clips',out.used_clips;'unique_pairs',out.unique_pairs}];
        if nt==2
            counts=[counts;{'primary_target_cards',deck.n_primary; ...
                'supplement_target_cards',deck.n_supplement}]; %#ok<AGROW>
        end
        v6_write_tsv(fullfile(folder,'COUNTS.tsv'),{'metric','value'},counts);
        save(fullfile(folder,'COMBINATION_RESULT.mat'),'out','-v7');
    end
end
function index=draw_recording(group,uses,caps)
eligible=group(uses(group)<caps(group));
assert(~isempty(eligible),'V6:Capacity','No eligible recording.');
weights=1./(1+uses(eligible));
j=find(cumsum(weights)>rand()*sum(weights),1,'first'); index=eligible(j);
end
function index=draw_clip(group,uses)
assert(~isempty(group),'V6:SourcePool','Recording has no prepared clip.');
weights=1./(1+uses(group));
j=find(cumsum(weights)>rand()*sum(weights),1,'first'); index=group(j);
end
