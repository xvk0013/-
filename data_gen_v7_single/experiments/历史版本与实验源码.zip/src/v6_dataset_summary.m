function report=v6_dataset_summary(cfg)
% Aggregate the three split reports; a full PASS requires every planned scene.
report=struct('complete',false,'requested_scenes',sum(cfg.totals), ...
    'accepted_scenes',0,'expected_WAV_count',numel(cfg.output_folders)*sum(cfg.totals),'WAV_count',0, ...
    'source_instances_committed',0,'primary_sir_scenes',0,'supplement_sir_scenes',0, ...
    'outside_sir_scenes',0,'card_band_mismatch_scenes',0, ...
    'quota_filled',true,'all_PCM_passed',true, ...
    'count_closure',true,'all_splits_processed',true);
splits=cell(numel(cfg.split_types),6); counts=cell(0,10); sir_counts=cell(0,13);
for si=1:numel(cfg.split_types)
    split=cfg.split_types{si}; folder=fullfile(cfg.run_root,'splits',split);
    summary_path=fullfile(folder,'SUMMARY.json');
    accepted=0; waves=0; filled=false; processed=false;
    if exist(summary_path,'file')==2
        s=jsondecode(fileread(summary_path));
        assert(s.requested_scenes==cfg.totals(si),'V6:SplitQuota','Split total disagrees with full plan.');
        accepted=s.accepted_scenes; waves=s.WAV_count;
        filled=s.quota_filled; processed=s.all_combinations_processed;
        report.source_instances_committed=report.source_instances_committed+s.source_instances_committed;
        report.primary_sir_scenes=report.primary_sir_scenes+s.primary_sir_scenes;
        report.supplement_sir_scenes=report.supplement_sir_scenes+s.supplement_sir_scenes;
        report.outside_sir_scenes=report.outside_sir_scenes+s.outside_sir_scenes;
        report.card_band_mismatch_scenes=report.card_band_mismatch_scenes+s.card_band_mismatch_scenes;
        report.all_PCM_passed=report.all_PCM_passed && s.all_PCM_passed;
        report.count_closure=report.count_closure && s.count_closure;
    end
    report.accepted_scenes=report.accepted_scenes+accepted; report.WAV_count=report.WAV_count+waves;
    report.quota_filled=report.quota_filled && filled;
    report.all_splits_processed=report.all_splits_processed && processed;
    splits(si,:)={split,cfg.totals(si),accepted,waves,filled,processed};
    local_counts=cell(0,9);
    p=fullfile(folder,'QUOTA_COUNTS.tsv'); if exist(p,'file')==2, local_counts=read_tsv_v3(p,9); end
    p=fullfile(folder,'SIR_COUNTS.tsv');
    if exist(p,'file')==2, sir_counts=[sir_counts;read_tsv_v3(p,13)]; end %#ok<AGROW>
    for k=1:numel(cfg.combo_names)
        name=cfg.combo_names{k}; q=cfg.scene_counts_by_split(si,k);
        ix=find(strcmp(local_counts(:,1),name)); assert(numel(ix)<=1);
        if isempty(ix)
            row={name,q,0,0,0,0,0,q,'not_started'};
        else
            row=local_counts(ix,:); assert(str2double(row{2})==q,'V6:Quota','Combination quota changed.');
        end
        counts(end+1,:)=[{split} row]; %#ok<AGROW>
    end
end
report.count_closure=report.count_closure && report.WAV_count==numel(cfg.output_folders)*report.accepted_scenes;
report.complete=report.quota_filled && report.all_splits_processed && report.all_PCM_passed && ...
    report.count_closure && ...
    report.accepted_scenes==report.requested_scenes && report.WAV_count==report.expected_WAV_count;
v6_write_tsv(fullfile(cfg.run_root,'SPLIT_COUNTS.tsv'), ...
    {'split','requested_scenes','accepted_scenes','WAV_count','quota_filled','all_combinations_processed'},splits);
v6_write_tsv(fullfile(cfg.run_root,'QUOTA_COUNTS.tsv'), ...
    {'split','combination','requested','accepted','attempted','numeric_rejected','pairing_rejected', ...
    'failed_or_inflight','shortage','stop_reason'},counts);
v6_write_tsv(fullfile(cfg.run_root,'SIR_COUNTS.tsv'), ...
    {'split','combination','accepted','primary_sir_scenes','supplement_sir_scenes', ...
    'outside_sir_scenes','primary_fraction_actual','supplement_fraction_actual', ...
    'primary_fraction_target','card_band_mismatch_scenes','used_recordings','used_clips','unique_pairs'},sir_counts);
v6_json(fullfile(cfg.run_root,'SUMMARY.json'),report);
v6_write_structs(fullfile(cfg.run_root,'SUMMARY.tsv'),report);
end
