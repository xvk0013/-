function y=apply_continuous_channel_v3(x,channel,history_samples,core_samples)
% Linear convolution of real history + core, then a valid receiver window.
x=x(:); N=numel(x); nfft=channel.nfft; P=channel.memory_samples;
assert(N==history_samples+core_samples && history_samples>=P, ...
    'Insufficient genuine source history for this channel.');
assert(nfft>=N+P,'FFT would wrap the linear convolution.');
assert(all(isfinite(x)) && numel(channel.H)==floor(nfft/2)+1);
Fx=fft(x,nfft); half=floor(nfft/2)+1;
positive=Fx(1:half).*channel.H;
positive(1)=real(positive(1));
if mod(nfft,2)==0
    positive(end)=real(positive(end)); full=[positive;conj(positive(end-1:-1:2))];
else
    full=[positive;conj(positive(end:-1:2))];
end
response=real(ifft(full));
y=response(history_samples+(1:core_samples));
assert(numel(y)==core_samples && all(isfinite(y)),'Invalid received core.');
end
