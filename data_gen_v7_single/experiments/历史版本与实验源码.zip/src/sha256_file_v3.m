function value = sha256_file_v3(path)
% Hash a regular file without reading past EOF. MATLAB may report EOF via
% ferror after an oversized fread; it is not evidence of file corruption.
fid=fopen(path,'rb');
assert(fid>=0,'sha256_file_v3:Open','Cannot hash: %s',path);
guard=onCleanup(@() fclose(fid));
assert(fseek(fid,0,'eof')==0,'sha256_file_v3:Seek','Cannot seek: %s',path);
expected_bytes=ftell(fid);
assert(expected_bytes>=0 && expected_bytes<=flintmax, ...
    'sha256_file_v3:Size','Cannot determine an exact file length: %s',path);
assert(fseek(fid,0,'bof')==0,'sha256_file_v3:Seek','Cannot rewind: %s',path);
md=java.security.MessageDigest.getInstance('SHA-256');
remaining=expected_bytes;
while remaining>0
    requested=min(remaining,1048576);
    [block,count]=fread(fid,requested,'*uint8');
    [msg,code]=ferror(fid);
    assert(count==requested,'sha256_file_v3:ShortRead', ...
        'Hash short read (%d/%d bytes): %s. %s',count,requested,path,msg);
    assert(code==0,'sha256_file_v3:Read','Hash read failed: %s. %s',path,msg);
    md.update(typecast(block,'int8'));
    remaining=remaining-count;
end
assert(ftell(fid)==expected_bytes,'sha256_file_v3:Position', ...
    'Hash byte position mismatch: %s',path);
assert(fseek(fid,0,'eof')==0,'sha256_file_v3:Seek','Cannot seek: %s',path);
assert(ftell(fid)==expected_bytes,'sha256_file_v3:SizeChanged', ...
    'File length changed while hashing: %s',path);
value=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
