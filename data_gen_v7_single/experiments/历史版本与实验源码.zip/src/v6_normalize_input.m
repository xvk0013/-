function [x,report]=v6_normalize_input(x,history_samples,cfg)
% Equal mean power for every effective input clip, across all audio classes.
% Use the same gain for genuine prehistory to preserve waveform continuity.
core=x(history_samples+1:end);
input_rms=sqrt(mean(core.^2));
gain=cfg.normalization.target_rms/input_rms;
x=x*gain;
report=struct('input_gain',gain,'input_rms_before',input_rms, ...
    'input_rms_after',sqrt(mean(x(history_samples+1:end).^2)));
end
