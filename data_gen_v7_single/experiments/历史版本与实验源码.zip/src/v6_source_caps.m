function [caps,groups]=v6_source_caps(cfg,recordings)
% Recording-level capacity is fixed from inventory and scene quotas.
groups=cell(1,numel(cfg.class_ids)); caps=zeros(numel(recordings),numel(cfg.combo_slots));
rows=cell(0,7);
for ci=1:numel(groups)
    groups{ci}=find([recordings.class_id]==cfg.class_ids(ci));
    assert(~isempty(groups{ci}),'V6:SourcePool','No recording for one class.');
end
for k=1:numel(cfg.combo_slots)
    for ci=cfg.combo_slots{k}
        n=numel(groups{ci}); q=cfg.scene_counts(k);
        cap=max(cfg.source_reuse.minimum_cap,ceil(cfg.source_reuse.capacity_headroom*q/n));
        caps(groups{ci},k)=cap;
        assert(n*cap>=q,'V6:Capacity','Recording capacity cannot fill the requested quota.');
        rows(end+1,:)={cfg.active_split,cfg.combo_names{k},cfg.class_names{ci},n,q,cap,n*cap}; %#ok<AGROW>
    end
end
v6_write_tsv(fullfile(cfg.output_root,'SOURCE_CAPS.tsv'), ...
    {'split','combination','class_name','usable_recordings','requested_scenes', ...
    'fixed_cap_per_recording','total_capacity'},rows);
fprintf('Recording reuse caps for %s frozen before candidate generation; see SOURCE_CAPS.tsv.\n',cfg.active_split);
end
