function [sources,recordings]=v6_prepare_sources(cfg,plan)
% Every eligible frozen clip is considered; propagation still uses RAW audio.
context=SourceContextBuilderV6(cfg,{cfg.active_split});
sources=struct('row',{},'context_path',{},'core_path',{},'context_hash',{}, ...
    'raw_hash',{},'input_gain',{},'input_rms_before',{},'input_rms_after',{},'status',{},'reasons',{},'recording_index',{});
recordings=struct('class_id',{},'class_name',{},'recording_key',{},'source_indices',{});
attempts=cell(0,7); selection=cell(0,7); count_rows=cell(numel(cfg.class_ids),5);
try
    for ci=1:numel(cfg.class_ids)
        pool=plan.pools{ci}; class_start=numel(sources); record_start=numel(recordings);
        for j=1:numel(pool)
            rows=pool(j).rows; indices=[]; recording_index=numel(recordings)+1;
            for r=1:size(rows,1)
                row=rows(r,:);
                [q,asset]=context.prepare(row,'mainline_reference');
                if ismember(q.status,{'PASS','REVIEW'}) && ~asset.resampler_boundary_free
                    q.status='REJECT'; q.reasons='FIR_SUPPORT_CROSSES_RECORD_BOUNDARY';
                end
                attempts(end+1,:)={row{1},row{2},row{4},row{5},row{6},q.status,q.reasons}; %#ok<AGROW>
                assert(~strcmp(q.status,'ERROR'),'V6:SourceEngineering', ...
                    'Source error: %s/%s segment %s (%s)',row{2},row{4},row{6},q.reasons);
                if strcmp(q.status,'REJECT'), continue; end
                [~,stem]=fileparts(row{5}); asset_name=[stem '.mat'];
                core=fullfile(cfg.output_root,'quality_sources',cfg.active_split,row{1},asset_name);
                q=context.materialize(row,q,asset,core);
                ctx=fullfile(cfg.output_root,'source_contexts',cfg.active_split,row{1},asset_name);
                rec=struct('row',{row},'context_path',ctx,'core_path',core, ...
                    'context_hash',sha256_file_v3(ctx),'raw_hash',asset.raw_hash, ...
                    'input_gain',asset.input_gain,'input_rms_before',asset.input_rms_before, ...
                    'input_rms_after',asset.input_rms_after, ...
                    'status',q.status, ...
                    'reasons',q.reasons,'recording_index',recording_index);
                sources(end+1)=rec; %#ok<AGROW>
                indices(end+1)=numel(sources); %#ok<AGROW>
                selection(end+1,:)={row{1},row{4},row{5},true,q.status,q.reasons,recording_index}; %#ok<AGROW>
            end
            if ~isempty(indices)
                recordings(end+1)=struct('class_id',cfg.class_ids(ci), ...
                    'class_name',cfg.class_names{ci},'recording_key',pool(j).key,'source_indices',indices); %#ok<AGROW>
            end
            checkpoint();
            if mod(j,10)==0 || j==numel(pool)
                fprintf('Sources %s/%s: %d/%d recordings checked; %d usable recordings, %d clips.\n', ...
                    cfg.active_split,cfg.class_names{ci},j,numel(pool), ...
                    numel(recordings)-record_start,numel(sources)-class_start);
            end
        end
        count_rows(ci,:)={cfg.class_ids(ci),plan.eligible_recordings(ci), ...
            plan.eligible_clips(ci),numel(recordings)-record_start,numel(sources)-class_start};
        assert(numel(recordings)>record_start,'V6:QCShortage', ...
            'No usable recording for %s/%s; see SOURCE_ATTEMPTS.tsv.',cfg.active_split,cfg.class_names{ci});
    end
catch err
    checkpoint(); rethrow(err);
end
checkpoint();
write_tsv_v3(fullfile(cfg.output_root,'SOURCE_COUNTS.tsv'), ...
    {'class_id','eligible_recordings','eligible_clips','usable_recordings','prepared_clips'},count_rows);
write_tsv_v3(fullfile(cfg.output_root,'SOURCE_SELECTION.tsv'), ...
    {'class_id','recording_key','segment_file','included','QC_status','QC_reasons','recording_index'},selection);
keys=string({recordings.class_name})+"/"+lower(string({recordings.recording_key}));
assert(numel(unique(keys))==numel(recordings),'V6:RecordingIndex','Duplicate recording.');
clip_keys=cellfun(@(r) [r{1} '/' r{5}],{sources.row},'UniformOutput',false);
assert(numel(unique(lower(string(clip_keys))))==numel(sources),'V6:ClipIndex','Duplicate frozen clip.');
assert(strcmp(sha256_file_v3(plan.manifest),plan.manifest_sha256),'V6:ManifestChanged','Source manifest changed.');
fprintf('Full source pool %s: %d recordings / %d prepared clips.\n', ...
    cfg.active_split,numel(recordings),numel(sources));

    function checkpoint()
        context.flush();
        write_tsv_v3(fullfile(cfg.output_root,'SOURCE_ATTEMPTS.tsv'), ...
            {'class_id','class_name','recording_key','segment_file','segment_index','status','reasons'},attempts);
    end
end
