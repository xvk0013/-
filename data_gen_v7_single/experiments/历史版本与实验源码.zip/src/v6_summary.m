function report=v6_summary(cfg,results,sources,recordings)
% Requested quota-count report; no independent parameter sweep.
counts=cell(0,9); usage=cell(0,7); sir_counts=cell(0,13);
primary_count=0; supplement_count=0; outside_count=0; card_mismatch_count=0;
scenes=struct([]); pcm=struct([]); global_uses=zeros(1,numel(recordings)); clip_uses=zeros(1,numel(sources));
for k=1:numel(results)
    r=results{k}; if isempty(r), continue; end
    counts(end+1,:)={r.combination,r.requested,r.accepted,r.attempted,r.numeric_rejected,r.pairing_rejected, ...
        r.failed_or_inflight,r.shortage,r.stop_reason}; %#ok<AGROW>
    primary_count=primary_count+r.primary_sir_scenes;
    supplement_count=supplement_count+r.supplement_sir_scenes;
    outside_count=outside_count+r.outside_sir_scenes;
    card_mismatch_count=card_mismatch_count+r.card_band_mismatch_scenes;
    if r.n_targets==2
        sir_counts(end+1,:)={cfg.active_split,r.combination,r.accepted,r.primary_sir_scenes, ...
            r.supplement_sir_scenes,r.outside_sir_scenes, ...
            r.primary_fraction_actual,r.supplement_fraction_actual,cfg.pairing.primary_fraction, ...
            r.card_band_mismatch_scenes, ...
            r.used_recordings,r.used_clips,r.unique_pairs}; %#ok<AGROW>
    end
    usage=[usage;r.source_usage_rows]; %#ok<AGROW>
    if ~isempty(r.selected)
        if isempty(scenes), scenes=r.selected; pcm=r.pcm;
        else, scenes=[scenes;r.selected]; pcm=[pcm;r.pcm]; end %#ok<AGROW>
    end
    global_uses=global_uses+r.recording_uses; clip_uses=clip_uses+r.source_uses;
end
v6_write_tsv(fullfile(cfg.output_root,'QUOTA_COUNTS.tsv'), ...
    {'combination','requested','accepted','attempted','numeric_rejected','pairing_rejected', ...
    'failed_or_inflight','shortage','stop_reason'},counts);
v6_write_tsv(fullfile(cfg.output_root,'SIR_COUNTS.tsv'), ...
    {'split','combination','accepted','primary_sir_scenes','supplement_sir_scenes', ...
    'outside_sir_scenes','primary_fraction_actual','supplement_fraction_actual', ...
    'primary_fraction_target','card_band_mismatch_scenes','used_recordings','used_clips','unique_pairs'},sir_counts);
v6_write_tsv(fullfile(cfg.output_root,'SOURCE_REUSE.tsv'), ...
    {'combination','split','class_name','recording_key','accepted_uses','max_uses','remaining_capacity'},usage);
totals=cell(numel(recordings),4);
for s=1:numel(recordings)
    row=recordings(s);
    totals(s,:)={cfg.active_split,row.class_name,row.recording_key,global_uses(s)};
end
clip_totals=cell(numel(sources),5);
for s=1:numel(sources)
    row=sources(s).row;
    clip_totals(s,:)={cfg.active_split,row{2},row{4},row{5},clip_uses(s)};
end
v6_write_tsv(fullfile(cfg.output_root,'SOURCE_CLIP_USES.tsv'), ...
    {'split','class_name','recording_key','segment_file','accepted_uses_all_combinations'},clip_totals);
assert(sum(clip_uses)==sum(global_uses),'V6:ReuseClosure','Split clip/recording uses disagree.');
v6_write_tsv(fullfile(cfg.output_root,'SOURCE_TOTAL_USES.tsv'), ...
    {'split','class_name','recording_key','accepted_uses_all_combinations'},totals);
v6_write_structs(fullfile(cfg.output_root,'SCENES.tsv'),scenes);
v6_write_structs(fullfile(cfg.output_root,'PCM_READBACK.tsv'),pcm);
quota_filled=all(cellfun(@(r) ~isempty(r) && r.quota_filled,results));
all_pcm=isempty(pcm) || all([pcm.passed]);
assert(all_pcm,'V6:AcceptedOutput','An accepted output violates its PCM contract.');
wave_count=0;
for k=1:numel(results)
    if isempty(results{k}), continue; end
    root=fullfile(cfg.dataset_root,cfg.combo_folders{k},cfg.active_split); expected=results{k}.accepted;
    for sub=cfg.output_folders
        actual=numel(dir(fullfile(root,sub{1},'*.wav')));
        assert(actual==expected,'V6:FileCount','WAV count disagrees with committed quota: %s/%s.',root,sub{1});
        wave_count=wave_count+actual;
    end
end
report=struct('quota_filled',quota_filled,'requested_scenes',sum(cfg.scene_counts), ...
    'accepted_scenes',numel(scenes),'WAV_count',wave_count, ...
    'source_instances_committed',sum(global_uses), ...
    'prepared_recordings',numel(recordings),'prepared_clips',numel(sources), ...
    'primary_sir_scenes',primary_count,'supplement_sir_scenes',supplement_count, ...
    'outside_sir_scenes',outside_count,'card_band_mismatch_scenes',card_mismatch_count, ...
    'all_PCM_passed',all_pcm, ...
    'count_closure',all(cellfun(@(r) isempty(r) || r.count_closure,results)) && ...
        wave_count==numel(cfg.output_folders)*numel(scenes), ...
    'all_combinations_processed',all(~cellfun(@isempty,results)));
v6_json(fullfile(cfg.output_root,'SUMMARY.json'),report);
v6_write_structs(fullfile(cfg.output_root,'SUMMARY.tsv'),report);
end
