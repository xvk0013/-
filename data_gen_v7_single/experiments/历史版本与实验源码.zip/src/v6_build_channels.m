function [channels,geometry]=v6_build_channels(cfg,plan)
% Map reciprocal ARR endpoints back to physical source/receiver coordinates.
fc=50:100:7950; arrays=cell(1,numel(fc)); Pos=[];
for k=1:numel(fc)
    [arrays{k},position]=read_arrivals_asc(plan.arr_files{k});
    if isempty(Pos), Pos=position; else
        assert(isequaln(Pos,position),'V6:ARRGeometry','ARR grids disagree.');
    end
end
assert(isequal(double(Pos.r.r(:).')/1000,cfg.ranges_km) && ...
    isequal(double(Pos.r.z(:).'),cfg.source_depths_m) && ...
    isequal(double(Pos.s.z(:).'),cfg.receiver_depth_m), ...
    'V6:Geometry','Expected reciprocal ARR geometry at the fixed physical receiver.');
N=round(cfg.segment_len_s*cfg.target_fs); P=round(cfg.source_history_s*cfg.target_fs);
nfft=2^nextpow2(N+P+round(cfg.max_delay_s*cfg.target_fs));
channels=cell(numel(cfg.ranges_km),numel(cfg.source_depths_m));
rows=cell(numel(channels),9); cursor=0;
for d=1:size(channels,2)
    for r=1:size(channels,1)
        amps=cell(1,numel(fc)); taus=amps;
        for k=1:numel(fc)
            amps{k}=double(arrays{k}(r,d,1).A); taus{k}=double(arrays{k}(r,d,1).delay);
        end
        H=build_channel_H_v3(amps,taus,fc,cfg.target_fs,nfft,cfg.max_delay_s);
        [channels{r,d},metrics]=causal_channel_v3(H,cfg.target_fs,nfft,cfg.max_delay_s,cfg.task_band_hz);
        cursor=cursor+1;
        rows(cursor,:)=[{cfg.ranges_km(r),cfg.source_depths_m(d),cfg.receiver_depth_m},num2cell(metrics)];
    end
end
geometry=struct('ranges_km',cfg.ranges_km,'source_depths_m',cfg.source_depths_m, ...
    'source_x_km',cfg.receiver_x_km+cfg.ranges_km, ...
    'receiver_x_km',cfg.receiver_x_km,'receiver_depth_m',cfg.receiver_depth_m, ...
    'method',cfg.geometry_method,'nfft',nfft,'f_centers',fc);
save(fullfile(cfg.output_root,'CHANNELS.mat'),'channels','geometry','-v7');
geometry_rows=cell(numel(channels),5); cursor=0;
for d=1:numel(cfg.source_depths_m)
    for r=1:numel(cfg.ranges_km)
        cursor=cursor+1;
        geometry_rows(cursor,:)={geometry.source_x_km(r),cfg.source_depths_m(d), ...
            cfg.receiver_x_km,cfg.receiver_depth_m,cfg.ranges_km(r)};
    end
end
write_tsv_v3(fullfile(cfg.output_root,'GEOMETRY.tsv'), ...
    {'source_x_km','source_depth_m','receiver_x_km','receiver_depth_m','range_km'},geometry_rows);
write_tsv_v3(fullfile(cfg.output_root,'CHANNEL_SUPPORT.tsv'), ...
    {'range_km','source_depth_m','receiver_depth_m','negative_time_energy_fraction', ...
    'late_energy_fraction','discarded_energy_fraction','complex_relative_l2_error', ...
    'integrated_gain_change_db','retained_energy_fraction'},rows);
fprintf('Mainline channels ready: %d ranges x %d source depths, receiver %.0f m.\n', ...
    size(channels,1),size(channels,2),geometry.receiver_depth_m);
end
