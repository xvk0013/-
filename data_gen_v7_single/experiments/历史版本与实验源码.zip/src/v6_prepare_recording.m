function [x,report,b]=v6_prepare_recording(raw,fs_in,cfg)
% Shared raw frontend; input power is normalized after selecting each clip.
x=mean(double(raw),2);
factor=gcd(fs_in,cfg.target_fs); p=cfg.target_fs/factor; q=fs_in/factor;
if fs_in==cfg.target_fs, b=1;
else, [x,b]=resample(x,p,q); end
removed_dc=mean(x); x=x-removed_dc;
report=struct('input_fs',fs_in,'output_fs',cfg.target_fs,'p',p,'q',q, ...
    'filter_taps',numel(b),'delay_output_samples',(numel(b)-1)/(2*q), ...
    'removed_record_dc',removed_dc,'method',cfg.resampler.method);
end
