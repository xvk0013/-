function seed=v6_seed(key,base)
md=java.security.MessageDigest.getInstance('SHA-256');
md.update(uint8(unicode2native(sprintf('%d|%s',base,char(key)),'UTF-8')));
bytes=typecast(md.digest(),'uint8');
seed=sum(double(bytes(1:4)).*reshape(256.^(3:-1:0),size(bytes(1:4))));
assert(seed>=0 && seed<2^32 && seed==floor(seed));
end
