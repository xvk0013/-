function v6_json(path,value)
fid=fopen(path,'wt','n','UTF-8'); assert(fid>=0,'WM:Write','Cannot write %s',path);
guard=onCleanup(@() fclose(fid));
fprintf(fid,'%s\n',jsonencode(value,'PrettyPrint',true));
[message,code]=ferror(fid); assert(code==0,'%s',message);
end
