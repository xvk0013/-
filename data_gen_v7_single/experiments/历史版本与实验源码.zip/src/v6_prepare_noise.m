function recordings=v6_prepare_noise(cfg,files)
% Load only the NaturalAmbientNoise recordings assigned to this split.
recordings=struct('file',{},'original_fs',{},'wave',{});
rows=cell(numel(files),5);
for k=1:numel(files)
    [x,fs]=audioread(files{k});
    x=v6_prepare_recording(x,fs,cfg);
    recordings(k)=struct('file',files{k},'original_fs',fs,'wave',x);
    rows(k,:)={cfg.active_split,files{k},fs,cfg.target_fs,numel(x)};
end
v6_write_tsv(fullfile(cfg.output_root,'NOISE_RECORDINGS.tsv'), ...
    {'split','file','original_fs','target_fs','resampled_samples'},rows);
end
