function v6_write_structs(path,records)
if isempty(records)
    v6_write_tsv(path,{'candidate_id'},cell(0,1)); return;
end
names=fieldnames(records).'; rows=cell(numel(records),numel(names));
for r=1:numel(records)
    for c=1:numel(names), rows{r,c}=records(r).(names{c}); end
end
v6_write_tsv(path,names,rows);
end
