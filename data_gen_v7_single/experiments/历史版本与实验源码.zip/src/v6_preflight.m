function plan=v6_preflight(cfg,require_arr)
% Metadata only: no audioread, audioinfo, filter design or generated output.
if nargin<2, require_arr=true; end
assert(ismember(cfg.active_split,cfg.split_types),'V6:Split','Preflight needs one concrete split.');
assert(exist(cfg.output_root,'file')==0,'WM:OutputExists','Use a NEW run ID: %s',cfg.output_root);
for name={'resample'}
    assert(exist(name{1},'file')~=0,'WM:Toolbox','Missing Signal Processing Toolbox function %s.',name{1});
end
manifest=fullfile(cfg.source_split_root,'recording_split_manifest.tsv');
assert(exist(manifest,'file')==2,'V6:MissingSplit', ...
    '尚未建立录音级清单：%s。点击运行 RUN_DATA_GEN_V6.m 将自动建立并继续生成。',manifest);
m=read_tsv_v3(manifest,6);
assert(all(ismember(m(:,3),cfg.split_types)) && all(ismember(str2double(m(:,1)),cfg.class_ids)));
pools=cell(1,numel(cfg.class_ids)); eligible=zeros(1,numel(cfg.class_ids)); eligible_clips=eligible;
for ci=1:numel(cfg.class_ids)
    id=cfg.class_ids(ci); rows=m(str2double(m(:,1))==id,:);
    assert(all(strcmp(rows(:,2),cfg.class_names{ci})));
    assert(numel(unique(lower(string(rows(:,5)))))==size(rows,1),'WM:Manifest','Duplicate source filename.');
    mapping=read_tsv_v3(fullfile(cfg.mapping_root,num2str(id),'segment_mapping.txt'),4);
    map_names=lower(string(mapping(:,1)));
    assert(numel(unique(map_names))==numel(map_names),'WM:Mapping','Duplicate mapping filename.');
    map_keys=lower(strtrim(string(mapping(:,2))))+"/"+lower(strtrim(string(mapping(:,3))));
    for r=1:size(rows,1)
        k=find(map_names==lower(string(rows{r,5})));
        assert(isscalar(k) && strcmpi(rows{r,4},char(map_keys(k))) && ...
            str2double(rows{r,6})==str2double(mapping{k,4}), ...
            'WM:Mapping','Frozen source provenance mismatch.');
        [folder,stem,ext]=fileparts(rows{r,5});
        assert(isempty(folder) && ~isempty(stem) && strcmpi(ext,'.wav') && ...
            ~contains(rows{r,5},{':','/','\'}),'WM:Filename','Unsafe source filename.');
    end
    all_keys=unique(lower(string(rows(:,4))));
    for k=1:numel(all_keys)
        assert(numel(unique(rows(lower(string(rows(:,4)))==all_keys(k),3)))==1, ...
            'WM:SplitLeak','Recording crosses frozen splits.');
    end
    train=rows(strcmp(rows(:,3),cfg.active_split),:);
    assert(size(train,1)==cfg.split_target_segments(strcmp(cfg.split_types,cfg.active_split)),'WM:Pool','Frozen selected-split pool size changed.');
    assert(exist(fullfile(cfg.raw_root,cfg.class_names{ci}),'dir')==7,'WM:RawRoot','Missing raw class.');
    ks=str2double(train(:,6)); assert(all(isfinite(ks) & ks==floor(ks) & ks>=1));
    train=train(ks>=2,:); keys=unique(lower(string(train(:,4))));
    order_seed=zeros(numel(keys),1);
    for k=1:numel(keys), order_seed(k)=v6_seed(sprintf('%d|%s',id,keys(k)),cfg.source_pool.selection_seed); end
    [~,order]=sort(order_seed); keys=keys(order);
    groups=struct('key',{},'rows',{});
    for k=1:numel(keys)
        selected=train(lower(string(train(:,4)))==keys(k),:);
        [~,o]=sort(str2double(selected(:,6))); selected=selected(o,:);
        groups(k).key=char(keys(k)); groups(k).rows=selected;
    end
    pools{ci}=groups; eligible(ci)=numel(groups); eligible_clips(ci)=size(train,1);
end
prefix='ReceiverAzi1';
arr_files=cell(1,80);
for k=1:80
    arr_files{k}=fullfile(cfg.arr_path,sprintf('%sfreq%dHz.arr',prefix,50+100*(k-1)));
    if require_arr
        assert(exist(arr_files{k},'file')==2,'WM:ARR','Missing ARR: %s',arr_files{k});
    end
end
assert(all(eligible>=1),'V6:SourcePool','A split/class has no eligible recording with real history.');
assert(strcmp(cfg.source_pool.selection,'all_QC_eligible_frozen_segments_with_history'));
plan=struct('manifest',manifest,'manifest_sha256',sha256_file_v3(manifest), ...
    'pools',{pools},'eligible_recordings',eligible,'eligible_clips',eligible_clips, ...
    'selection',cfg.source_pool.selection,'arr_files',{arr_files},'source_metadata_only',true);
plan.noise_files=fullfile(cfg.shipsear_root,cfg.shipsear_files.(cfg.active_split));
fprintf('PREFLIGHT %s: %s recordings / %s clips by class; use all QC-eligible clips; no audio decoded.\n', ...
    cfg.active_split,mat2str(eligible),mat2str(eligible_clips));
fprintf('Scene quotas: %s; output: %s\n',mat2str(cfg.scene_counts),cfg.dataset_root);
fprintf('ShipsEar noise class: %d recording files for %s.\n',numel(plan.noise_files),cfg.active_split);
end
