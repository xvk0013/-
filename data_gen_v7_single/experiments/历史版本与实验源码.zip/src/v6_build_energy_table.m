function cache=v6_build_energy_table(cfg,cache)
% One full 5-second receiver energy for every (source, range, depth). The pair
% scheduler reads these exact float32-scale values, so the table must be
% rebuilt whenever ARR runs, channels or normalization change. Search-style
% get_core calls keep waveforms in bounded memory only.
nS=numel(cache.sources); nR=numel(cfg.ranges_km); nD=numel(cfg.source_depths_m);
energy=nan(nS,nR,nD);
for index=1:nS
    for d=1:nD
        for r=1:nR
            [y,cache]=v6_get_core(cfg,cache,index,r,d,false);
            energy(index,r,d)=sum(double(single(y*cfg.output_gain)).^2);
        end
    end
    if mod(index,500)==0
        fprintf('Energy table: %d/%d sources.\n',index,nS);
    end
end
assert(all(isfinite(energy(:))),'V6:EnergyTable','Non-finite table energy.');
cache.energy_table=energy;
table_info=struct('revision',cfg.revision,'run_id',cfg.run_id, ...
    'geometry_method',cfg.geometry_method,'receiver_model',cfg.receiver_model, ...
    'ranges_km',cfg.ranges_km,'source_depths_m',cfg.source_depths_m);
save(fullfile(cfg.output_root,'ENERGY_TABLE.mat'),'energy','table_info','-v7');
fprintf('Energy table complete: %d sources x %d ranges x %d depths.\n',nS,nR,nD);
end
