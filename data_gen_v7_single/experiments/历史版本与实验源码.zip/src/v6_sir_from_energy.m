function s=v6_sir_from_energy(energy,cfg)
% Mainline energies refer to both references over the same full 5-second window.
signed=10*log10(energy(1)/energy(2));
sir=abs(signed); band='outside';
if sir>cfg.pairing.primary_bounds_db(1) && sir<cfg.pairing.primary_bounds_db(2)
    band='primary';
elseif sir>cfg.pairing.supplement_bounds_db(1) && sir<cfg.pairing.supplement_bounds_db(2)
    band='supplement';
end
stronger=1; if signed<0, stronger=2; end
s=struct('sir_db',sir,'signed_sir_db',signed,'sir_band',band, ...
    'energy1',energy(1),'energy2',energy(2),'stronger_source',stronger);
end
