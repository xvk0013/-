function [folder,signature]=v6_acoustic_assets(cfg)
% Content-based folder: the same acoustics survive project moves and new runs.
template=fullfile(cfg.project_root,'acoustics','template_pos1');
assets=cell(0,2);
for extension={'.env','.ssp','.bty','.brc','.ati','.trc','.sbp'}
    path=[template extension{1}];
    if exist(path,'file')==2
        assets(end+1,:)={extension{1},sha256_file_v3(path)}; %#ok<AGROW>
    end
end
signature=struct('geometry_method',cfg.geometry_method, ...
    'receiver_x_km',cfg.receiver_x_km,'receiver_depth_m',cfg.receiver_depth_m, ...
    'source_depths_m',cfg.source_depths_m,'ranges_km',cfg.ranges_km, ...
    'frequencies_hz',50:100:7950,'templates',{assets}, ...
    'generator_sha256',sha256_file_v3(fullfile(cfg.project_root,'src','v6_generate_arr.m')), ...
    'bellhop_sha256',sha256_file_v3(cfg.bellhop_executable));
md=java.security.MessageDigest.getInstance('SHA-256');
md.update(typecast(uint8(unicode2native(jsonencode(signature),'UTF-8')),'int8'));
key=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
folder=fullfile(cfg.project_root,'acoustics','arr',key);
end
