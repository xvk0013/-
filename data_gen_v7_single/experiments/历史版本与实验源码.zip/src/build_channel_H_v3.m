function H=build_channel_H_v3(cell_Amp,cell_tau,f_centers,fs,N_pad,max_delay)
% ARR phase is exp(+1i*phase); Fourier propagation is exp(-1i*2*pi*f*tau).
% t0 is REAL and common to all frequency anchors at this geometry. Only the
% real delays determine ray retention; imaginary seconds remain in tau.
% exp(-1i*2*pi*f*(tau-t0)) =
% exp(-1i*2*pi*f*(real(tau)-t0)) * exp(2*pi*f*imag(tau)).
% Do not fold absorption into A at fc and then apply it a second time here.
assert(numel(cell_Amp)==numel(f_centers) && numel(cell_tau)==numel(f_centers));
assert(numel(f_centers)>=2 && all(diff(f_centers)>0));
for k=1:numel(cell_tau)
    assert(numel(cell_Amp{k})==numel(cell_tau{k}) && ...
        all(isfinite(cell_Amp{k}(:))) && all(isfinite(cell_tau{k}(:))), ...
        'Invalid ARR amplitude/complex delay.');
end
fk=(0:N_pad-1)'/N_pad*fs;
half_N=floor(N_pad/2)+1;
fk_half=fk(1:half_N);
global_min_tau=inf;
for i=1:numel(cell_tau)
    if ~isempty(cell_tau{i}), global_min_tau=min(global_min_tau,min(real(cell_tau{i}))); end
end
if ~isfinite(global_min_tau), error('Bellhop 信道没有有效到达。'); end
H=zeros(half_N,1);
for i=1:numel(f_centers)-1
    fL=f_centers(i); fR=f_centers(i+1);
    if numel(f_centers)==2
        idx=(1:half_N)'; % the same interval owns both extrapolation ends
    elseif i==1
        idx=find(fk_half>=0 & fk_half<=fR);
    elseif i==numel(f_centers)-1
        idx=find(fk_half>fL & fk_half<=fs/2);
    else
        idx=find(fk_half>fL & fk_half<=fR);
    end
    if isempty(idx), continue; end
    f_eval=fk_half(idx);
    tauL_all=real(cell_tau{i})-global_min_tau;
    tauR_all=real(cell_tau{i+1})-global_min_tau;
    maskL=tauL_all<=max_delay; maskR=tauR_all<=max_delay;
    % Subtract only the common real origin: subtracting a complex origin
    % would incorrectly remove the earliest path's absorption.
    tauL=cell_tau{i}(maskL)-global_min_tau;
    tauR=cell_tau{i+1}(maskR)-global_min_tau;
    ampL=cell_Amp{i}(maskL); ampR=cell_Amp{i+1}(maskR);
    if isempty(ampL)
        HL=zeros(1,numel(idx));
    else
        % 使用绝对频率 f 和完整复延迟，同时计入相位与虚延迟衰减。
        HL=(ampL(:).')*exp(-1j*2*pi*tauL(:)*f_eval(:).');
    end
    if isempty(ampR)
        HR=zeros(1,numel(idx));
    else
        HR=(ampR(:).')*exp(-1j*2*pi*tauR(:)*f_eval(:).');
    end
    wR=(f_eval(:).'-fL)/(fR-fL);
    if i==1, wR(f_eval(:).'<fL)=0; end
    if i==numel(f_centers)-1, wR(f_eval(:).'>fR)=1; end
    H(idx)=(1-wR).*HL+wR.*HR;
end
assert(all(isfinite(H)),'Nonfinite complex-delay channel response.');
end
