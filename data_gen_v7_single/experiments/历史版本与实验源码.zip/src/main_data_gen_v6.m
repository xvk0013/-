function out=main_data_gen_v6(mode,run_id,profile)
% One entry generates all frozen splits; numeric execution is user-run.
if nargin<1, mode='preflight'; end
if nargin<2, run_id=char(datetime('now','Format','yyyyMMdd_HHmmss_SSS')); end
if nargin<3, profile='full_dataset'; end
assert(ismember(mode,{'preflight','generate'}),'V6:Mode','Use preflight or generate.');
cfg=cargo_v6_config(run_id,'all',profile); out=cfg.run_root;
assert(exist(out,'file')==0,'V6:OutputExists','Use a NEW run ID: %s',out);
if strcmp(mode,'generate'), v6_prepare_source_split(cfg); end
fprintf('V6 %s: Train %d / Test %d / Val %d = %d scenes, %d dataset WAVs.\n', ...
    strrep(upper(cfg.profile),'_',' '),cfg.totals,sum(cfg.totals), ...
    numel(cfg.output_folders)*sum(cfg.totals));
fprintf('Shared frontend: mono -> rational resampling -> DC removal -> crop -> effective 5s input RMS=1.\n');
fprintf('DeepShip: normalized core/history -> Bellhop -> full-5s receiver sum; ShipsEar: normalized 5s clip -> Train-referenced receiver level. Fixed output gain -> float32 WAV.\n');
fprintf('Geometry: fixed receiver x=%.2f km, z=%.0f m; reciprocal Bellhop, 80 ARR files -> %d channels.\n', ...
    cfg.receiver_x_km,cfg.receiver_depth_m,numel(cfg.ranges_km)*numel(cfg.source_depths_m));
fprintf('Pairs: stratified target deck, %.0f%% primary (0,5) dB and the rest supplement (5,10) dB; keeper prior-drawn, matcher table-scheduled on the %.2f km grid.\n', ...
    100*cfg.pairing.primary_fraction,cfg.ranges_km(2)-cfg.ranges_km(1));
plans=cell(size(cfg.split_types)); split_cfgs=plans;
for si=1:numel(cfg.split_types)
    split_cfgs{si}=cargo_v6_config(run_id,cfg.split_types{si},profile);
    plans{si}=v6_preflight(split_cfgs{si},false);
    assert(strcmp(plans{si}.manifest_sha256,plans{1}.manifest_sha256),'V6:ManifestChanged','Split manifests differ.');
end
if strcmp(mode,'preflight'), return; end
[ok,msg]=mkdir(out); assert(ok,'%s',msg);
stage='building_channels'; reports=cell(size(cfg.split_types));
try
    v6_status(cfg,false,stage,'none');
    save(fullfile(out,'RUN_CONFIG.mat'),'cfg','plans','-v7');
    copyfile(plans{1}.manifest,fullfile(out,'recording_split_manifest.tsv'));
    copyfile(fullfile(cfg.source_split_root,'SOURCE_SPLIT_PROTOCOL.json'), ...
        fullfile(out,'SOURCE_SPLIT_PROTOCOL.json'));
    v6_json(cfg.protocol_path,cfg);
    v6_dataset_summary(cfg);
    % Reuse project acoustic assets across runs with identical settings.
    v6_generate_arr(cfg);
    copyfile(fullfile(cfg.arr_path,'ARR_PROTOCOL.json'),fullfile(out,'ARR_PROTOCOL.json'));
    [channels,geometry]=v6_build_channels(cfg,plans{1});
    for si=1:numel(cfg.split_types)
        stage=['generating_' cfg.split_types{si}]; v6_status(cfg,false,stage,'none');
        reports{si}=run_split(split_cfgs{si},plans{si},channels,geometry,cfg);
        v6_dataset_summary(cfg);
    end
    report=v6_dataset_summary(cfg);
    save(fullfile(out,'RUN_RESULTS.mat'),'cfg','reports','report','-v7');
    if report.complete
        v6_status(cfg,true,'full_dataset_quota_PCM_passed','none');
        fprintf('V6 FULL DATASET PASS: %d/%d scenes, %d WAVs; Train/Test/Val complete.\n%s\n', ...
            report.accepted_scenes,report.requested_scenes,report.WAV_count,out);
    else
        v6_status(cfg,false,'complete_with_shortage','See QUOTA_COUNTS.tsv.');
        fprintf('V6 FULL DATASET WITH SHORTAGE: %d/%d scenes; see QUOTA_COUNTS.tsv.\n%s\n', ...
            report.accepted_scenes,report.requested_scenes,out);
    end
catch err
    v6_status(cfg,false,stage,[err.identifier ': ' err.message]);
    save(fullfile(out,'PARTIAL_RESULTS.mat'),'cfg','reports','-v7');
    rethrow(err);
end
end

function report=run_split(cfg,plan,channels,geometry,root_cfg)
[ok,msg]=mkdir(cfg.output_root); assert(ok,'%s',msg);
results=cell(1,numel(cfg.combo_slots)); sources=struct([]); recordings=struct([]);
stage='preparing_sources';
try
    v6_status(cfg,false,stage,'none');
    v6_json(cfg.protocol_path,cfg);
    [sources,recordings]=v6_prepare_sources(cfg,plan);
    noise_recordings=v6_prepare_noise(cfg,plan.noise_files);
    [recording_caps,groups]=v6_source_caps(cfg,recordings);
    save(fullfile(cfg.output_root,'SOURCES.mat'),'sources','recordings','recording_caps','groups','-v7');
    save(fullfile(cfg.output_root,'RUN_CONFIG.mat'),'cfg','plan','recording_caps','-v7');
    [ok,msg]=mkdir(cfg.cache_root); assert(ok,'%s',msg);
    wave_shape=[numel(sources) numel(cfg.ranges_km) numel(cfg.source_depths_m)];
    cache=struct('sources',sources,'recordings',recordings,'recording_caps',recording_caps, ...
        'noise_recordings',noise_recordings, ...
        'groups',{groups},'channels',{channels},'geometry',geometry, ...
        'contexts',{cell(numel(sources),1)},'context_ticks',zeros(numel(sources),1), ...
        'context_count',0,'waves',{cell(wave_shape)},'wave_ticks',zeros(wave_shape), ...
        'wave_count',0,'clock',0);
    stage='building_energy_table';
    v6_status(cfg,false,stage,'none');
    cache=v6_build_energy_table(cfg,cache);
    % Finish ship scenes first. Fit Fix-D on Train only, then reuse that
    % frozen reference for noise in every split.
    for k=[2:numel(cfg.combo_slots) 1]
        if k==1
            stage='preparing_noise_level_reference'; v6_status(cfg,false,stage,'none');
            reference_path=fullfile(cfg.run_root,'NOISE_LEVEL_REFERENCE.mat');
            if strcmp(cfg.active_split,cfg.noise_level.reference_split)
                reference=v6_fit_noise_level(cfg,results);
                save(reference_path,'reference','-v7');
            else
                saved=load(reference_path,'reference'); reference=saved.reference;
            end
            cache.noise_level_reference=reference;
        end
        stage=['generating_' cfg.combo_names{k}]; v6_status(cfg,false,stage,'none');
        [results{k},cache]=v6_run_combo(cfg,cache,k);
        v6_summary(cfg,results,sources,recordings);
        v6_dataset_summary(root_cfg);
    end
    assert(strcmp(sha256_file_v3(plan.manifest),plan.manifest_sha256),'V6:ManifestChanged','Frozen manifest changed.');
    report=v6_summary(cfg,results,sources,recordings);
    save(fullfile(cfg.output_root,'RUN_RESULTS.mat'),'cfg','results','report','-v7');
    complete=report.quota_filled && report.all_PCM_passed && report.count_closure;
    if complete
        v6_status(cfg,true,'quota_and_PCM_passed','none');
        fprintf('V6 %s PASS: %d/%d scenes, %d WAVs.\n',cfg.active_split, ...
            report.accepted_scenes,report.requested_scenes,report.WAV_count);
    else
        v6_status(cfg,false,'complete_with_shortage','See QUOTA_COUNTS.tsv.');
        fprintf('V6 %s WITH SHORTAGE: %d/%d scenes.\n',cfg.active_split, ...
            report.accepted_scenes,report.requested_scenes);
    end
catch err
    v6_status(cfg,false,stage,[err.identifier ': ' err.message]);
    save(fullfile(cfg.output_root,'PARTIAL_RESULTS.mat'),'cfg','results','sources','recordings','-v7');
    rethrow(err);
end
end
