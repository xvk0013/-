function v6_write_tsv(path, header, rows)
% Small, explicit TSV writer; cells may contain scalar numbers or text.
fid = fopen(path,'wt','n','UTF-8');
assert(fid>=0,'Cannot write: %s',path);
guard = onCleanup(@() fclose(fid));
data = [header; rows];
for r=1:size(data,1)
    fields = cell(1,size(data,2));
    for c=1:size(data,2)
        v=data{r,c};
        if isnumeric(v) || islogical(v)
            if isscalar(v), v=sprintf('%.17g',v); else, v=mat2str(v,17); end
        end
        fields{c}=regexprep(char(v),'[\t\r\n]',' ');
    end
    fprintf(fid,'%s\n',strjoin(fields,sprintf('\t')));
end
[msg,code]=ferror(fid);
assert(code==0,'TSV write failed: %s',msg);
end
