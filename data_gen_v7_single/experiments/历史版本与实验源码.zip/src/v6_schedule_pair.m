function [p,state]=v6_schedule_pair(cfg,cache,slots,state,depths,keeper,target_signed,keeper_source)
% Keeper: balanced recording/clip queues; initial range is prior-drawn.
% Matcher: (clip, range) candidates whose full-window table
% energies put the predicted signed SIR within tolerance of the target.
% L3 may redraw the keeper range after a band mismatch. Lookup only;
% no propagation and no SIR rejection here; exhausted capacity is
% the only failure mode.
p=struct('found',false,'reason','no_eligible_keeper');
matcher=3-keeper;
if isempty(keeper_source)
    keeper_source=draw_keeper(keeper);
    if keeper_source==0, return; end
end
keeper_range=randi(numel(cfg.ranges_km));
e_keeper=cache.energy_table(keeper_source,keeper_range,depths(keeper));
matcher_group=cache.groups{slots(matcher)};
matcher_clips=[];
for rec=matcher_group(state.recording_uses(matcher_group)<state.recording_caps(matcher_group))
    rec_clips=cache.recordings(rec).source_indices;
    rec_clips=rec_clips(state.clip_uses(rec_clips)<state.clip_caps(rec_clips));
    matcher_clips=[matcher_clips rec_clips(arrayfun(@pair_open,rec_clips))]; %#ok<AGROW>
end
if isempty(matcher_clips)
    p=struct('found',false,'reason','no_eligible_matcher'); return;
end
energies=cache.energy_table(matcher_clips,:,depths(matcher));
if keeper==1
    predicted=10*log10(e_keeper./energies);
else
    predicted=10*log10(energies./e_keeper);
end
deviation=abs(predicted-target_signed);
deviation(~isfinite(deviation))=inf;
% Exclude equal horizontal ranges in every shortlist and nearest fallback.
% Source depths remain independent and may be equal.
deviation(:,keeper_range)=inf;
tol=cfg.pairing.tolerance_db;
mask=deviation<=tol;
while nnz(mask)<cfg.pairing.shortlist_min && ...
        tol<cfg.pairing.tolerance_db+3*cfg.pairing.tolerance_widen_step_db
    tol=tol+cfg.pairing.tolerance_widen_step_db;
    mask=deviation<=tol;
end
tolerance_miss=~any(mask(:));
if tolerance_miss
    if min(deviation(:))==inf
        p=struct('found',false,'reason','no_eligible_matcher'); return;
    end
    mask=deviation==min(deviation(:));
end
[clip_rows,range_cols]=find(mask);
% find 给出列向量，而逗号列表索引的 cand_clips 继承源的方向（行）；
% 三者强制列向量化，否则下方 candidates 拼接会因行列混杂失败。
cand_clips=matcher_clips(clip_rows); cand_clips=cand_clips(:);
range_cols=range_cols(:);
cand_pred=predicted(sub2ind(size(predicted),clip_rows,range_cols)); cand_pred=cand_pred(:);
cand_recordings=[cache.sources(cand_clips).recording_index];
weights=1./((1+state.recording_uses(cand_recordings)).* ...
    (1+state.clip_uses(cand_clips)).*(1+state.range_uses(range_cols)));
n_pick=min(numel(cand_clips),1+cfg.pairing.candidate_switches_max);
picks=zeros(1,n_pick); available=true(1,numel(weights));
for pick=1:n_pick
    wk=weights.*available;
    j=find(cumsum(wk)>rand*sum(wk),1);
    picks(pick)=j; available(j)=false;
end
p=struct('found',true,'reason','scheduled', ...
    'keeper_source',keeper_source,'keeper_range',keeper_range,'keeper_slot',keeper, ...
    'candidates',[cand_clips(picks(:)) range_cols(picks(:)) cand_pred(picks(:))], ...
    'predicted_signed_db',cand_pred(picks(1)),'shortlist_size',numel(cand_clips), ...
    'tolerance_db',tol,'tolerance_miss',tolerance_miss);

    function index=draw_keeper(which)
        group=cache.groups{slots(which)};
        eligible=group(state.recording_uses(group)<state.recording_caps(group));
        eligible=eligible(arrayfun(@(r) ~isempty(available_clips(r)),eligible));
        index=0; if isempty(eligible), return; end
        queue=state.record_queues{which}; queue=queue(ismember(queue,eligible));
        if isempty(queue)
            queue=eligible(randperm(numel(eligible)));
            [~,order]=sort(state.recording_uses(queue)); queue=queue(order);
        end
        recording=queue(1); state.record_queues{which}=queue(2:end);
        clips=available_clips(recording);
        queue=state.clip_queues{recording}; queue=queue(ismember(queue,clips));
        if isempty(queue)
            queue=clips(randperm(numel(clips)));
            [~,order]=sort(state.clip_uses(queue)); queue=queue(order);
        end
        index=queue(1); state.clip_queues{recording}=queue(2:end);
    end

    function clips=available_clips(recording)
        clips=cache.recordings(recording).source_indices;
        clips=clips(state.clip_uses(clips)<state.clip_caps(clips));
    end

    function tf=pair_open(clip_index)
        pair=zeros(1,2); pair(keeper)=keeper_source; pair(matcher)=clip_index;
        key=sprintf('%d_%d',pair);
        tf=~isKey(state.pair_uses,key) || state.pair_uses(key)<cfg.pairing.max_pair_uses;
    end
end
