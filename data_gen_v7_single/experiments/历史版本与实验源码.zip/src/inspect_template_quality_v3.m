function q = inspect_template_quality_v3(path,cfg,expected_samples)
% PASS = no obvious engineering fault, NOT a verified vessel identity.
% REVIEW is descriptive only; it has the same quota/weight as PASS.
if nargin<3, expected_samples=round(cfg.segment_len_s*cfg.target_fs); end
q=struct('status','PASS','reasons','none','sha256','unavailable', ...
    'peak',nan,'near_zero_s',nan, ...
    'near_zero_start_s',nan,'flat_peak_samples',nan, ...
    'flat_peak_start_s',nan,'transient_fraction',nan,'transient_start_s',nan);
if exist(path,'file')~=2
    q.status='ERROR'; q.reasons='MISSING_FILE'; return;
end
try
    q.sha256=sha256_file_v3(path);
catch
    q.status='ERROR'; q.reasons='FILE_IO_ERROR'; return;
end
try
    [x,fs]=audioread(path);
catch
    q.status='REJECT'; q.reasons='DECODE_FAILED'; return;
end
hash=q.sha256;
q=inspect_waveform_quality_v3(x,fs,cfg,expected_samples);
q.sha256=hash;
end
