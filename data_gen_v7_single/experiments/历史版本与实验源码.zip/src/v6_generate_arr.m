function v6_generate_arr(cfg)
% Reciprocal point-source calculation in one common ocean coordinate system.
% Computational source = physical receiver; computational receivers = ships.
frequencies=50:100:7950;
complete_path=fullfile(cfg.arr_path,'ARR_COMPLETE.mat');
arr_files=arrayfun(@(f) fullfile(cfg.arr_path,sprintf('ReceiverAzi1freq%dHz.arr',f)), ...
    frequencies,'UniformOutput',false);
if exist(complete_path,'file')==2 && all(cellfun(@isfile,arr_files))
    saved=load(complete_path,'signature');
    assert(isequaln(saved.signature,cfg.arr_signature),'V6:ARRSettings','ARR settings differ.');
    fprintf('Reusing %d project ARR files: %s\n',numel(frequencies),cfg.arr_path);
    return;
end
template=fullfile(cfg.this_dir,'acoustics','template_pos1');
lines=regexp(fileread([template '.env']),'\r?\n','split');
source_line=find(contains(lines,'! NSz'),1);
lines{source_line}='1 ! NSz: computational source at physical receiver';
lines{source_line+1}=sprintf('%.10g / ! Sz (m)',cfg.receiver_depth_m);
depth_line=find(contains(lines,'! NRz'),1);
lines{depth_line}=sprintf('%d ! NRz: physical source depths',numel(cfg.source_depths_m));
lines{depth_line+1}=[sprintf('%.10g ',cfg.source_depths_m) '/ ! Rz (m)'];
range_line=find(contains(lines,'! NRr'),1);
lines{range_line}=sprintf('%d ! NRr',numel(cfg.ranges_km));
lines{range_line+1}=[sprintf('%.10g ',cfg.ranges_km) '/ ! Rr (km)'];
% The existing bathymetry/SSP abscissa is global X; the receiver is at X=0.
% Stop rays at the mapped boundary rather than beyond its last bathymetry point.
fid=fopen([template '.bty'],'rt'); fgetl(fid); fgetl(fid);
bottom=fscanf(fid,'%f',[2 Inf]).'; fclose(fid);
box_line=find(contains(lines,'Box.r'),1); box=sscanf(lines{box_line},'%f',3);
lines{box_line}=sprintf('%.10g %.10g %.10g ! deltas Box.z Box.r', ...
    box(1),box(2),bottom(end,1));
run_line=find(contains(lines,'! Run Type'),1);
lines{run_line}='''AB R'' ! Run Type: arrivals, Gaussian beams, omnidirectional point source';
if ~exist(cfg.arr_path,'dir'), mkdir(cfg.arr_path); end
previous=pwd; restore_folder=onCleanup(@() cd(previous)); cd(cfg.arr_path);
for k=1:numel(frequencies)
    prefix=sprintf('ReceiverAzi1freq%dHz',frequencies(k));
    lines{2}=sprintf('%.2f ! Frequency (Hz)',frequencies(k));
    fid=fopen([prefix '.env'],'wt');
    fprintf(fid,'%s\n',lines{:}); fclose(fid);
    for extension={'.ssp','.bty','.brc','.ati','.trc','.sbp'}
        input=[template extension{1}];
        if exist(input,'file'), copyfile(input,[prefix extension{1}]); end
    end
    fprintf('Bellhop reciprocal receiver: %d/%d frequencies, %d ranges (%.1f--%.1f km).\n', ...
        k,numel(frequencies),numel(cfg.ranges_km),cfg.ranges_km(1),cfg.ranges_km(end));
    [status,message]=system(sprintf('"%s" %s',cfg.bellhop_executable,prefix));
    assert(status==0,'V6:Bellhop','Bellhop failed for %s: %s',prefix,message);
    assert(exist([prefix '.arr'],'file')==2,'Bellhop did not generate %s.arr.',prefix);
end
signature=cfg.arr_signature;
v6_json(fullfile(cfg.arr_path,'ARR_PROTOCOL.json'),signature);
save(complete_path,'signature');
fprintf('Saved %d reusable project ARR files: %s\n',numel(frequencies),cfg.arr_path);
end
