function q=inspect_waveform_quality_v3(x,fs,cfg,expected_samples)
% Same conservative rules for a core, real history, or full context.
q=struct('status','PASS','reasons','none','sha256','unavailable', ...
    'peak',nan,'near_zero_s',nan, ...
    'near_zero_start_s',nan,'flat_peak_samples',nan, ...
    'flat_peak_start_s',nan,'transient_fraction',nan,'transient_start_s',nan);
if isempty(x), q.status='REJECT'; q.reasons='EMPTY'; return; end
if any(~isfinite(x(:))), q.status='REJECT'; q.reasons='NONFINITE'; return; end
if all(x(:)==0), q.status='REJECT'; q.reasons='ALL_ZERO'; return; end
if fs~=cfg.target_fs || size(x,1)~=expected_samples || size(x,2)~=1
    q.status='ERROR'; q.reasons='FORMAT_MISMATCH'; return;
end
x=double(x(:));
if all(x==x(1)), q.status='REJECT'; q.reasons='CONSTANT_DC'; return; end
q.peak=max(abs(x));
reasons={};
[n,start]=longest_run(abs(x)<=cfg.quality.near_zero_relative*q.peak);
q.near_zero_s=n/fs; q.near_zero_start_s=(start-1)/fs;
if q.near_zero_s>=cfg.quality.dropout_min_s, reasons{end+1}='SUSPECT_DROPOUT'; end
if q.peak<cfg.quality.near_silence_peak, reasons{end+1}='NEAR_SILENCE'; end
flat=abs(x(2:end))>=cfg.quality.clipping_level & abs(diff(x))<=cfg.quality.flat_tolerance;
[n,start]=longest_run(flat);
q.flat_peak_samples=n+(n>0); q.flat_peak_start_s=(start-1)/fs;
if q.flat_peak_samples>=cfg.quality.clipping_min_samples, reasons{end+1}='SUSPECT_CLIPPING'; end
width=max(1,round(cfg.quality.transient_window_s*fs));
energy=movsum(x.^2,[0 width-1],'Endpoints','shrink');
[peak_energy,start]=max(energy);
q.transient_fraction=peak_energy/max(sum(x.^2),realmin);
q.transient_start_s=(start-1)/fs;
if q.transient_fraction>=cfg.quality.transient_energy_fraction
    reasons{end+1}='SUSPECT_TRANSIENT';
end
if ~isempty(reasons), q.status='REVIEW'; q.reasons=strjoin(reasons,';'); end
end

function [n,start]=longest_run(mask)
d=diff([false;mask(:);false]); starts=find(d==1); stops=find(d==-1)-1;
if isempty(starts), n=0; start=nan; return; end
[n,k]=max(stops-starts+1); start=starts(k);
end
