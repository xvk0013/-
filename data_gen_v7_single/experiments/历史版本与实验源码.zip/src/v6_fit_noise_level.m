function reference=v6_fit_noise_level(cfg,results)
% Fit receiver levels to accepted Train ship mixes, measured after readback.
% Each ship scene contributes one RMS; sample by interpolating between
% neighboring log-RMS order statistics.
rms_values=[];
for k=2:numel(results)
    pcm=results{k}.pcm;
    rms_values=[rms_values [pcm.mix_rms]]; %#ok<AGROW>
end
reference=struct('method',cfg.noise_level.method, ...
    'revision',cfg.revision,'source_run',cfg.run_id, ...
    'source_split',cfg.active_split,'scene_count',numel(rms_values), ...
    'log_rms_sorted',sort(log(rms_values)));
end
