function manifest=v6_prepare_source_split(cfg)
% Build once from provenance metadata; subsequent runs reuse the frozen split.
% No audio decoding, denoising or reuse of a clip-level Train/Test/Val folder.
manifest=fullfile(cfg.source_split_root,'recording_split_manifest.tsv');
if exist(manifest,'file')==2
    fprintf('Reusing frozen recording split: %s\n',manifest); return;
end
rows=cell(0,6); partition=cell(0,5);
recording_counts=zeros(numel(cfg.class_ids),numel(cfg.split_types));
mapping_hashes=cell(1,numel(cfg.class_ids));
for ci=1:numel(cfg.class_ids)
    id=cfg.class_ids(ci); name=cfg.class_names{ci};
    mapping_path=fullfile(cfg.mapping_root,num2str(id),'segment_mapping.txt');
    mapping=read_tsv_v3(mapping_path,4);
    mapping_hashes{ci}=sha256_file_v3(mapping_path);
    indices=str2double(mapping(:,4));
    assert(all(isfinite(indices) & indices>=1 & indices==floor(indices)), ...
        'V6:Mapping','Invalid original segment index: %s',mapping_path);
    mapping=mapping(indices>=2,:); % Segment 1 has no real three-second history.
    map_keys=lower(string(mapping(:,2))+"/"+string(mapping(:,3)));
    keys=unique(map_keys); ranks=zeros(numel(keys),1);
    wavs=dir(fullfile(cfg.raw_root,name,'**','*.wav'));
    raw_keys=strings(numel(wavs),1);
    for j=1:numel(wavs)
        [~,parent]=fileparts(wavs(j).folder); [~,stem]=fileparts(wavs(j).name);
        raw_keys(j)=lower(string(parent)+"/"+string(stem));
    end
    assert(all(ismember(keys,raw_keys)),'V6:RawSource', ...
        '来源映射中的原始录音不完整：%s。',fullfile(cfg.raw_root,name));
    for j=1:numel(keys)
        ranks(j)=v6_seed(sprintf('split|%d|%s',id,keys(j)),cfg.source_split.seed);
    end
    [~,order]=sort(ranks); keys=keys(order);
    exact=numel(keys)*cfg.source_split.recording_fractions;
    counts=floor(exact);
    [~,remainder_order]=sort(exact-counts,'descend');
    for j=1:numel(keys)-sum(counts)
        counts(remainder_order(j))=counts(remainder_order(j))+1;
    end
    recording_counts(ci,:)=counts;
    groups=cell(numel(keys),1);
    for j=1:numel(keys)
        group=find(map_keys==keys(j)); clip_ranks=zeros(numel(group),1);
        for k=1:numel(group)
            clip_ranks(k)=v6_seed(sprintf('clip|%d|%s|%s', ...
                id,keys(j),mapping{group(k),4}),cfg.source_split.seed);
        end
        [~,order]=sort(clip_ranks); groups{j}=group(order);
    end
    offset=0;
    for si=1:numel(cfg.split_types)
        assigned=offset+(1:counts(si)); offset=offset+counts(si);
        target=cfg.split_target_segments(si);
        assert(sum(cellfun(@numel,groups(assigned)))>=target,'V6:SplitCapacity', ...
            '%s/%s 的录音划分不足 %d 个候选片段。',cfg.split_types{si},name,target);
        for j=assigned
            partition(end+1,:)={id,name,cfg.split_types{si},char(keys(j)),numel(groups{j})}; %#ok<AGROW>
        end
        selected=zeros(target,1); cursor=ones(numel(keys),1); n=0;
        while n<target
            for j=assigned
                if cursor(j)>numel(groups{j}), continue; end
                n=n+1; selected(n)=groups{j}(cursor(j)); cursor(j)=cursor(j)+1;
                if n==target, break; end
            end
        end
        for k=selected.'
            rows(end+1,:)={id,name,cfg.split_types{si},char(map_keys(k)),mapping{k,1},mapping{k,4}}; %#ok<AGROW>
        end
        fprintf('New source split %s/%s: %d recordings, %d frozen candidate clips.\n', ...
            cfg.split_types{si},name,counts(si),target);
    end
end
if ~exist(cfg.source_split_root,'dir'), mkdir(cfg.source_split_root); end
protocol=cfg.source_split;
protocol.created_at=char(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));
protocol.raw_root=cfg.raw_root; protocol.mapping_root=cfg.mapping_root;
protocol.class_ids=cfg.class_ids; protocol.class_names=cfg.class_names;
protocol.splits=cfg.split_types; protocol.recording_counts=recording_counts;
protocol.candidate_clips_per_class=cfg.split_target_segments;
protocol.mapping_sha256=mapping_hashes;
protocol.old_deleted_split_restored=false;
protocol.QC='raw_resampled_history_and_core_before_normalization_at_each_run';
v6_json(fullfile(cfg.source_split_root,'SOURCE_SPLIT_PROTOCOL.json'),protocol);
write_tsv_v3(fullfile(cfg.source_split_root,'RECORDING_PARTITION.tsv'), ...
    {'class_id','class_name','split','recording_key','available_clips_with_history'},partition);
write_tsv_v3(manifest, ...
    {'class_id','class_name','split','recording_key','segment_file','segment_index'},rows);
fprintf('New recording split saved for reuse: %s\n',manifest);
end
