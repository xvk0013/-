function [y,cache]=v6_get_core(cfg,cache,index,r,d,persist)
% Exact double-precision disk reuse with bounded LRU memory; no waveform change.
if nargin<6, persist=true; end
cache.clock=cache.clock+1;
asset=fullfile(cfg.cache_root,sprintf('ref_%05d_r%02d_d%02d.mat',index,r,d));
y=cache.waves{index,r,d};
if ~isempty(y)
    if persist && exist(asset,'file')~=2, save(asset,'y','-v6'); end
    cache.wave_ticks(index,r,d)=cache.clock; return;
end
N=round(cfg.segment_len_s*cfg.target_fs); P=round(cfg.source_history_s*cfg.target_fs);
if exist(asset,'file')==2
    saved=load(asset,'y'); y=saved.y;
else
    if isempty(cache.contexts{index})
        src=cache.sources(index);
        assert(strcmp(sha256_file_v3(src.context_path),src.context_hash),'V6:ContextChanged','Context changed.');
        context=load(src.context_path,'x','fs'); x=context.x;
        assert(context.fs==cfg.target_fs && isequal(size(x),[P+N 1]));
        if cache.context_count>=cfg.cache.contexts_in_memory
            eligible=find(cache.context_ticks>0);
            [~,j]=min(cache.context_ticks(eligible)); victim=eligible(j);
            cache.contexts{victim}=[]; cache.context_ticks(victim)=0;
            cache.context_count=cache.context_count-1;
        end
        cache.contexts{index}=x; cache.context_count=cache.context_count+1;
    end
    cache.context_ticks(index)=cache.clock;
    y=apply_continuous_channel_v3(cache.contexts{index},cache.channels{r,d},P,N);
    assert(isequal(size(y),[N 1]) && isreal(y) && all(isfinite(y)) && any(y~=0), ...
        'V6:Propagation','Invalid propagated reference.');
    if persist, save(asset,'y','-v6'); end % Search-only waves stay in bounded memory.
end
assert(isequal(size(y),[N 1]) && isreal(y) && all(isfinite(y)) && any(y~=0), ...
    'V6:PropagationCache','Invalid cached propagated reference.');
if cache.wave_count>=cfg.cache.waveforms_in_memory
    eligible=find(cache.wave_ticks>0);
    [~,j]=min(cache.wave_ticks(eligible)); victim=eligible(j);
    cache.waves{victim}=[]; cache.wave_ticks(victim)=0;
    cache.wave_count=cache.wave_count-1;
end
cache.waves{index,r,d}=y; cache.wave_ticks(index,r,d)=cache.clock;
cache.wave_count=cache.wave_count+1;
end
