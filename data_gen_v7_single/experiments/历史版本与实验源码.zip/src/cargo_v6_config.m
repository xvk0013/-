function cfg=cargo_v6_config(run_id,active_split,profile)
% Standalone V6 mainline configuration; no legacy or experiment configuration.
root=v6_paths();
if nargin<1, run_id=char(datetime('now','Format','yyyyMMdd_HHmmss_SSS')); end
if nargin<2, active_split='all'; end
if nargin<3, profile='full_dataset'; end
run_id=char(run_id); active_split=char(active_split);
assert(ismember(profile,{'full_dataset','pilot'}),'V6:Profile','Unknown profile: %s',profile);
assert(~isempty(regexp(run_id,'^[A-Za-z0-9_-]{1,64}$','once')),'V6:RunID','Invalid run ID.');
paths=v6_local_config(); data_root=paths.data_root;
cfg=struct();
cfg.data_root=data_root;
cfg.class_ids=[0 1 3]; cfg.class_names={'Cargo','Tanker','Tug'};
cfg.raw_root=fullfile(data_root,'DeepShip');
cfg.mapping_root=fullfile(root,'sources','mapping');
cfg.source_split_root=fullfile(root,'sources','split');
cfg.bellhop_executable=paths.bellhop_executable;
% ShipsEar NaturalAmbientNoise: preserve the existing recording-level split.
cfg.shipsear_root=fullfile(data_root,'shipsEar_AUDIOS');
cfg.shipsear_files=struct();
cfg.shipsear_files.Train={'81__25_09_13_H3_corriente.wav', ...
    '82__27_09_13_H3_lluvia.wav','83__27_09_13_H3_oleaje.wav', ...
    '84__27_09_13_H3_viento.wav','85__E__1L.wav','86__E__2M.wav', ...
    '87__E__3H.wav','88__E__4L.wav'};
cfg.shipsear_files.Test={'89__E__5M.wav','90__E__6H.wav'};
cfg.shipsear_files.Val={'91__E__7H_N.wav','92__E__8H_N.wav'};
cfg.noise_level=struct('method','train_ship_mix_log_rms_empirical', ...
    'reference_split','Train');
cfg.target_fs=16000; cfg.segment_len_s=5;
cfg.split_types={'Train','Test','Val'};
cfg.split_target_segments=[700 150 150]; % frozen source segments per class, not output scene counts
cfg.source_split=struct('revision','rebuilt_recording_split_v1','seed',47, ...
    'recording_fractions',[0.70 0.15 0.15], ...
    'recording_order','seeded_SHA256_rank_within_class', ...
    'recording_counts','largest_remainder_Train_Test_Val_tie_order', ...
    'clip_selection','round_robin_recordings_with_seeded_clip_order');
cfg.normalization=struct('method','mean_power','scope','effective_5s_input', ...
    'target_rms',1,'stage','after_segmentation_before_Bellhop', ...
    'history_gain','same_as_core');
cfg.max_delay_s=3.0; cfg.source_history_s=3.0;
cfg.channel_support='explicit_causal_fir_0_to_max_delay';
cfg.receiver_model='continuous_sources_full_5s_receiver_sum';
% Retained only for the independent historical envelope experiment.
cfg.solo_range_s=[0.3 1.5]; cfg.fade_range_s=[0.3 0.8];
cfg.channel_phase='absolute_frequency_with_common_delay_origin';
cfg.channel_absorption='arr_complex_delay_at_absolute_frequency';
cfg.quality=struct('replacement_seed',48,'near_zero_relative',1e-4, ...
    'dropout_min_s',0.25,'near_silence_peak',1e-5, ...
    'clipping_level',0.98,'flat_tolerance',1/32768, ...
    'clipping_min_samples',4,'transient_window_s',0.05, ...
    'transient_energy_fraction',0.50);
cfg.revision='data_gen_v6_full_overlap_common_receiver_fixd_v5';
cfg.run_id=run_id; cfg.profile=profile; cfg.active_split=active_split;
cfg.this_dir=root; cfg.project_root=root;
cfg.layout_revision='portable_assets_20260916';
cfg.reference=struct('semantics','reference_template_with_residual_background', ...
    'absolute_SL_assigned',false,'background_removed',false, ...
    'normalization','effective_5s_mean_power_before_Bellhop');
cfg.task_band_hz=[0 8000];
cfg.resampler=struct('method','MATLAB_rational_polyphase_resample');
cfg.source_pool=struct('selection','all_QC_eligible_frozen_segments_with_history', ...
    'selection_seed',47,'clips_per_recording','all_eligible');
cfg.source_sampling='inverse_accepted_uses_with_cap';
% Freeze caps from the QC source inventory BEFORE generating any candidates.
% The old fixed cap of 10 cannot support the original full dataset quotas.
cfg.source_reuse=struct('minimum_cap',10,'capacity_headroom',2, ...
    'cap_rule','max(minimum_cap,ceil(capacity_headroom*combo_quota/usable_recordings_in_class))', ...
    'scope','per_recording_per_combination_per_split', ...
    'within_recording_sampling','inverse_accepted_clip_uses', ...
    'relax_during_generation',false);
cfg.cache=struct('waveforms_in_memory',128,'contexts_in_memory',8, ...
    'propagated_disk_cache',true);
% Singles and pairs share the same available distance grid.
cfg.single_ranges_km=1:0.25:4;
cfg.pairing=struct('primary_fraction',0.80, ...
    'primary_bounds_db',[0 5],'supplement_bounds_db',[5 10], ...
    'deck_primary_draw_db',[0.3 4.7],'deck_supplement_draw_db',[5.3 9.7], ...
    'tolerance_db',2,'shortlist_min',5,'tolerance_widen_step_db',1, ...
    'candidate_switches_max',2,'keeper_redraws_max',1, ...
    'max_pair_uses',2,'minimum_clip_cap',2,'clip_capacity_headroom',2, ...
    'verification','band_membership');
cfg.pairing.source_sampling='shuffled_recording_and_clip_queues_ordered_by_accepted_uses';
cfg.ranges_km=cfg.single_ranges_km;
cfg.source_depths_m=[5 10 15];
cfg.receiver_x_km=0; cfg.receiver_depth_m=1000;
cfg.geometry_method='reciprocal_fixed_receiver_same_side';
cfg.physical_seed=48;
cfg.attempts=struct('minimum_per_combination',2000,'factor_per_requested_scene',50);
cfg.progress_every_scenes=100;
cfg.combo_slots={[],1,2,3,[1 2],[1 3],[2 3]};
cfg.combo_names={'noise','Cargo','Tanker','Tug','Cargo_Tanker','Cargo_Tug','Tanker_Tug'};
cfg.combo_folders={'noise','0','1','2','0_1','0_2','1_2'};
% Restore the original noise/single/pair quotas in all three splits. The
% pilot profile keeps the same structure at reduced scale; decks, reuse caps
% and attempt budgets all derive from these counts automatically.
if strcmp(profile,'pilot')
    cfg.scene_counts_by_split=[20 20 20 20 40 40 40; ...
                               10 10 10 10 15 15 15; ...
                               10 10 10 10 15 15 15];
else
    cfg.scene_counts_by_split=[1386 1838 1838 1838 1530 1530 1530; ...
                              291  394  394  394  330  330  330; ...
                              291  394  394  394  330  330  330];
end
cfg.totals=sum(cfg.scene_counts_by_split,2).'; % Train / Test / Val
assert(strcmp(active_split,'all') || ismember(active_split,cfg.split_types));
cfg.run_root=fullfile(paths.output_root,run_id);
[cfg.arr_path,cfg.arr_signature]=v6_acoustic_assets(cfg);
if strcmp(active_split,'all')
    cfg.scene_counts=sum(cfg.scene_counts_by_split,1);
    cfg.output_root=cfg.run_root;
else
    si=find(strcmp(cfg.split_types,active_split));
    cfg.scene_counts=cfg.scene_counts_by_split(si,:);
    cfg.output_root=fullfile(cfg.run_root,'splits',active_split);
end
cfg.max_attempts_per_combination=max(cfg.attempts.minimum_per_combination, ...
    cfg.attempts.factor_per_requested_scene*cfg.scene_counts);
cfg.dataset_root=fullfile(cfg.run_root,'dataset');
cfg.cache_root=fullfile(cfg.output_root,'propagated_cache');
cfg.protocol_path=fullfile(cfg.output_root,'PROTOCOL.json');
cfg.output_bits=32; cfg.output_encoding='IEEE_float32'; cfg.output_gain=1;
cfg.output_folders={'mix','s1','s2','s3'};
cfg.pcm=struct('sample_error_ulp_max',1.00001,'closure_error_ulp_max',3.00003);
assert(isequal(cfg.task_band_hz,[0 cfg.target_fs/2]) && ...
    cfg.target_fs==16000 && cfg.segment_len_s==5 && cfg.source_history_s==3);
validateattributes(cfg.scene_counts_by_split,{'numeric'}, ...
    {'size',[numel(cfg.split_types) numel(cfg.combo_slots)],'integer','nonnegative','finite'});
assert(isequal(sum(cfg.scene_counts_by_split,2).',cfg.totals),'V6:Totals','Split quotas must match full totals.');
assert(all(cfg.scene_counts_by_split(:,2)==cfg.scene_counts_by_split(:,3)) && ...
    all(cfg.scene_counts_by_split(:,3)==cfg.scene_counts_by_split(:,4)));
assert(all(cfg.scene_counts_by_split(:,5)==cfg.scene_counts_by_split(:,6)) && ...
    all(cfg.scene_counts_by_split(:,6)==cfg.scene_counts_by_split(:,7)));
validateattributes(cfg.source_reuse.minimum_cap,{'numeric'},{'scalar','integer','positive','finite'});
validateattributes(cfg.source_reuse.capacity_headroom,{'numeric'},{'scalar','real','>=',1,'finite'});
validateattributes(cfg.cache.waveforms_in_memory,{'numeric'},{'scalar','integer','positive','finite'});
validateattributes(cfg.cache.contexts_in_memory,{'numeric'},{'scalar','integer','positive','finite'});
validateattributes(cfg.max_attempts_per_combination,{'numeric'}, ...
    {'vector','numel',numel(cfg.combo_slots),'integer','positive','finite'});
assert(strcmp(cfg.source_sampling,'inverse_accepted_uses_with_cap'));
assert(~cfg.source_reuse.relax_during_generation && cfg.cache.propagated_disk_cache);
assert(all(cfg.scene_counts<=cfg.max_attempts_per_combination));
end
