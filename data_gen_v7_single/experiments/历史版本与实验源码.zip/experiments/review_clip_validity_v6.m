function review_clip_validity_v6(out,clip_id)
% Listen/inspect and save manual labels. Running this helper is user-controlled.
addpath(fullfile(fileparts(fileparts(mfilename('fullpath'))),'src'),'-begin');
if nargin<2, clip_id=''; end
data=load(fullfile(out,'EXPERIMENT.mat'),'e'); e=data.e;
path=fullfile(out,'LABELS.tsv'); [labels,header]=read_tsv_v3(path,4);
if isempty(clip_id), todo=find(strcmp(labels(:,2),'pending') | cellfun(@isempty,labels(:,2)));
else
    todo=find(strcmp(labels(:,1),clip_id)); assert(isscalar(todo),'Unknown review clip ID.');
end
fprintf('v=valid, i=invalid, u=uncertain, r=replay, h=history+core, q=save and quit.\n');
fprintf('Playback uses peak gain for audibility. Do not judge validity by playback volume.\n');
for row=reshape(todo,1,[])
    id=labels{row,1}; s=load(fullfile(out,'review',[id '.mat']));
    core=[]; if ~isempty(s.x), core=s.x(s.item.history_samples+1:end); end
    fig=figure('Name',['Validity review ' id],'NumberTitle','off','Position',[100 80 1050 780]);
    tiledlayout(fig,3,1,'TileSpacing','compact');
    nexttile;
    if isempty(core) || any(~isfinite(core))
        axis off; text(0.05,0.5,'Source unavailable or nonfinite; inspect the reason in REVIEW_MANIFEST.tsv.');
    else
        plot((0:numel(core)-1)/s.fs,core); xlabel('Time (s)'); ylabel('Before normalization');
        title(sprintf('%s | raw RMS %.6g | RMS normalization gain %.2f dB', ...
            id,s.item.raw_rms,s.item.normalization_gain_db),'Interpreter','none');
    end
    nexttile;
    if isempty(s.x) || any(~isfinite(s.x)), axis off;
    else
        plot(((0:numel(s.x)-1)-s.item.history_samples)/s.fs,s.x);
        xline(0,'r--'); xlabel('Time relative to core (s)'); ylabel('History + core');
    end
    nexttile;
    if numel(core)>=e.spectral_window_samples && all(isfinite(core)) && any(core~=0)
        [S,F,T]=spectrogram(core,hann(e.spectral_window_samples,'periodic'), ...
            e.spectral_window_samples-e.spectral_hop_samples,e.spectral_window_samples,s.fs);
        P=abs(S).^2;
        imagesc(T,F,10*log10(max(P/max(P(:)),1e-10))); axis xy; caxis([-80 0]);
        xlabel('Time (s)'); ylabel('Frequency (Hz)'); colorbar;
        title('Relative spectral power (dB); display scaling only');
    else, axis off; end
    expected='vessel content';
    if strcmp(s.item.class_name,'noise'), expected='natural ambient noise; vessel structure is NOT required'; end
    sgtitle(sprintf('%s | Expected: %s',id,expected),'Interpreter','none'); drawnow;
    play(core,s.fs);
    while true
        answer=lower(strtrim(input([id ' [v/i/u/r/h/q]: '],'s')));
        if strcmp(answer,'q'), if isgraphics(fig), close(fig); end; return; end
        if strcmp(answer,'r'), play(core,s.fs); continue; end
        if strcmp(answer,'h'), play(s.x,s.fs); continue; end
        if ~ismember(answer,{'v','i','u'}), continue; end
        if strcmp(answer,'v'), label='valid'; reason='none';
        elseif strcmp(answer,'u'), label='uncertain'; reason='unclear';
        else
            label='invalid';
            reason=strtrim(input('Reason (fault / background_only / other): ','s'));
            if isempty(reason), reason='other'; end
        end
        note=input('Note (Enter to skip): ','s');
        labels(row,2:4)={label,reason,note};
        v6_write_tsv(path,header,labels); break;
    end
    if isgraphics(fig), close(fig); end
end
fprintf('No pending clips in this review selection. Labels saved to %s\n',path);
end

function play(x,fs)
if ~isempty(x) && all(isfinite(x)) && any(x~=0)
    sound(0.8*x/max(abs(x)),fs);
else
    fprintf('No finite nonzero waveform available for playback.\n');
end
end
