function out=experiment_level_blind_v6(run_id,target_rms)
% LB（电平盲）消融数据派生：对一次已完成的生成运行，把每个场景的
% mix/s1/s2/s3 同乘一个逐场景标量 g=target_rms/RMS(mix)，镜像写入
% <run_id>_LB。全局标量不改变谱形、时序与场景内相对电平（SIR 严格
% 保持），只销毁绝对电平；B 条件就是原始数据集本身，两条件按相同
% 文件名逐场景配对。在数据侧销毁电平后，任何下游前端在 LB 条件下
% 都无法利用绝对电平，训练代码无须改动。
addpath(fullfile(fileparts(fileparts(mfilename('fullpath'))),'src'),'-begin');
if nargin<2, target_rms=1; end
run_id=char(run_id);
v6_paths(); paths=v6_local_config();
src_root=fullfile(paths.output_root,run_id);
dst_root=fullfile(paths.output_root,[run_id '_LB']);
assert(exist(src_root,'dir')==7,'V6:LB','Source run not found: %s',src_root);
assert(exist(dst_root,'file')==0,'V6:LB','Output already exists: %s',dst_root);
if exist(fullfile(src_root,'RUN_RESULTS.mat'),'file')~=2
    warning('V6:LB','Source run has no RUN_RESULTS.mat and may be incomplete.');
end
channels={'mix','s1','s2','s3'};
dataset_src=fullfile(src_root,'dataset');
combo_entries=dir(dataset_src);
combo_names=sort({combo_entries([combo_entries.isdir] & ...
    ~ismember({combo_entries.name},{'.','..'})).name});
manifest=cell(0,8); scene_count=0; clock_start=tic;
for ci=1:numel(combo_names)
    combo=combo_names{ci};
    split_entries=dir(fullfile(dataset_src,combo));
    split_names=sort({split_entries([split_entries.isdir] & ...
        ~ismember({split_entries.name},{'.','..'})).name});
    for si=1:numel(split_names)
        split=split_names{si};
        folder_src=fullfile(dataset_src,combo,split);
        lists=cell(1,4);
        for c=1:4
            path=fullfile(folder_src,channels{c});
            assert(exist(path,'dir')==7,'V6:LB','Missing channel folder: %s',path);
            w=dir(fullfile(path,'*.wav'));
            lists{c}=sort({w.name});
        end
        assert(isequal(lists{:}),'V6:LB','Channel file lists disagree: %s',folder_src);
        for c=1:4
            dst_folder=fullfile(dst_root,'dataset',combo,split,channels{c});
            if ~exist(dst_folder,'dir'), [ok,msg]=mkdir(dst_folder); assert(ok,'%s',msg); end
        end
        for fi=1:numel(lists{1})
            name=lists{1}{fi};
            scene_count=scene_count+1;
            original=cell(1,4); fs=NaN;
            for c=1:4
                [y,f]=audioread(fullfile(folder_src,channels{c},name));
                original{c}=double(y);
                if isnan(fs), fs=f; else, assert(f==fs,'V6:LB','Sample rates disagree: %s',name); end
            end
            n=numel(original{1});
            assert(all(cellfun(@(y) isequal(size(y),[n 1]),original)), ...
                'V6:LB','Channel lengths disagree: %s',name);
            rms_before=sqrt(mean(original{1}.^2));
            assert(isfinite(rms_before) && rms_before>0,'V6:LB','Invalid mix RMS: %s',name);
            gain=target_rms/rms_before;
            scaled=cell(1,4); peak=0;
            for c=1:4
                scaled{c}=single(original{c}*gain);
                peak=max(peak,max(abs(scaled{c}(:))));
            end
            q=double(eps(single(peak)));
            sample_error=0; decoded=cell(1,4);
            for c=1:4
                dst_path=fullfile(dst_root,'dataset',combo,split,channels{c},name);
                assert(exist(dst_path,'file')==0,'V6:LB','Output already exists: %s',dst_path);
                audiowrite(dst_path,scaled{c},fs,'BitsPerSample',32);
                [back,f]=audioread(dst_path);
                assert(f==fs && isequal(size(back),[n 1]), ...
                    'V6:LB','Readback format mismatch: %s',name);
                decoded{c}=back;
                sample_error=max(sample_error,max(abs(back-double(scaled{c}))));
            end
            sample_error=sample_error/q;
            % 噪声场景的 mix 是背景本身；其余场景 mix 应为三路参考之和。
            background=zeros(n,1);
            if strcmp(combo,'noise'), background=decoded{1}; end
            closure=max(abs(decoded{1}-(decoded{2}+decoded{3}+decoded{4})-background))/q;
            % 闭包容差比生产宽：原数据集自身闭包误差与逐路二次舍入叠加。
            assert(sample_error<=1.00001,'V6:LB','Sample readback failed: %s',name);
            assert(closure<=6.00006,'V6:LB','Closure failed: %s',name);
            manifest(end+1,:)={split,combo,name,gain,rms_before, ...
                sqrt(mean(decoded{1}.^2)),sample_error,closure}; %#ok<AGROW>
            if mod(scene_count,500)==0
                fprintf('LB: %d scenes transformed (%.0f s elapsed).\n', ...
                    scene_count,toc(clock_start));
            end
        end
    end
end
summary=cell(0,9);
[unique_splits,~,split_map]=unique(manifest(:,1),'stable');
for a=1:numel(unique_splits)
    split_rows=split_map==a;
    combos_here=unique(manifest(split_rows,2),'stable');
    for b=1:numel(combos_here)
        sel=split_rows & strcmp(manifest(:,2),combos_here{b});
        gains=cell2mat(manifest(sel,4));
        before=cell2mat(manifest(sel,5));
        summary(end+1,:)={unique_splits{a},combos_here{b},numel(gains), ...
            min(gains),median(gains),max(gains), ...
            min(before),median(before),max(before)}; %#ok<AGROW>
    end
end
protocol=struct('source_run',run_id,'b_condition_root',src_root,'lb_root',dst_root, ...
    'target_rms',target_rms,'transform','per_scene_global_gain_on_mix_s1_s2_s3', ...
    'sir_invariant',true,'scene_pairing','identical file names and structure', ...
    'created',char(datetime('now','Format','yyyy-MM-dd HH:mm:ss')));
v6_json(fullfile(dst_root,'LB_PROTOCOL.json'),protocol);
v6_write_tsv(fullfile(dst_root,'LB_MANIFEST.tsv'), ...
    {'split','combination','file_name','gain','rms_before','rms_after', ...
    'sample_error_ulp','closure_error_ulp'},manifest);
v6_write_tsv(fullfile(dst_root,'LB_SUMMARY.tsv'), ...
    {'split','combination','scenes','gain_min','gain_median','gain_max', ...
    'rms_before_min','rms_before_median','rms_before_max'},summary);
fprintf('LB complete: %d scenes -> %s\n',scene_count,dst_root);
out=struct('source_run',run_id,'lb_root',dst_root,'target_rms',target_rms, ...
    'scenes',scene_count,'manifest',{manifest},'summary',{summary});
end
