function out=experiment_clip_validity_v6(mode,run_or_path)
% PREPARE -> user labels -> ANALYZE. No Bellhop, model training or production edits.
addpath(fullfile(fileparts(fileparts(mfilename('fullpath'))),'src'),'-begin');
if nargin<1, mode='prepare'; end
if nargin<2, run_or_path=''; end
if strcmp(mode,'analyze')
    out=char(run_or_path);
    v6_clip_validity_analyze(out); return;
end
assert(strcmp(mode,'prepare'),'Use prepare or analyze.');
if isempty(run_or_path), run_or_path=char(datetime('now','Format','yyyyMMdd_HHmmss_SSS')); end
cfg=cargo_v6_config(run_or_path,'Train');
v6_prepare_source_split(cfg);
out=fullfile(cfg.data_root,'data_gen_v6_clip_validity',cfg.run_id);
assert(~exist(out,'dir'),'Use a new experiment run ID: %s',out);
e=struct('revision','clip_validity_experiment_v1','seed',4817, ...
    'source_split','Train','calibration_recording_fraction',2/3, ...
    'class_names',{{'Cargo','Tanker','Tug','noise'}}, ...
    'random_labels_per_class',[90 90 90 40], ...
    'stress_labels_per_class',[20 20 20 20],'noise_pool_per_recording',40, ...
    'energy_window_s',0.10,'energy_hop_s',0.05,'low_frame_relative_db',-40, ...
    'transient_window_s',0.05,'spectral_window_samples',1024,'spectral_hop_samples',256, ...
    'threshold_quantiles',[0.05 0.10 0.25 0.50 0.75 0.90 0.95], ...
    'max_calibration_valid_false_reject_fraction',0.02,'max_joint_terms',3);
mkdir(out); mkdir(fullfile(out,'review'));
old=rng; restore_rng=onCleanup(@() rng(old)); rng(e.seed,'twister');
manifest=read_tsv_v3(fullfile(cfg.source_split_root,'recording_split_manifest.tsv'),6);
manifest=manifest(strcmp(manifest(:,3),'Train') & str2double(manifest(:,6))>=2,:);
records=source_recordings(cfg,manifest);
items=struct([]);
for r=1:numel(records)
    rec=records(r);
    fprintf('Validity inventory: %d/%d recordings (%s).\n',r,numel(records),rec.class_name);
    [wave,front,error_reason]=load_recording(rec.path,cfg);
    N=cfg.target_fs*cfg.segment_len_s; P=cfg.target_fs*cfg.source_history_s;
    if strcmp(rec.class_name,'noise')
        % Nonoverlapping five-second windows, sampled within this Train recording.
        blocks=floor(numel(wave)/N);
        if blocks>0, segments=sort(randperm(blocks,min(blocks,e.noise_pool_per_recording)));
        else, segments=1; end
        rows=cell(numel(segments),6);
        for j=1:numel(segments)
            rows(j,:)={'noise','noise','Train',rec.key,sprintf('window_%06d',segments(j)),num2str(segments(j))};
        end
        history=0;
    else
        rows=rec.rows; history=P;
    end
    first_item=numel(items)+1;
    for j=1:size(rows,1)
        k=str2double(rows{j,6}); first=(k-1)*N+1; last=k*N;
        available=isempty(error_reason) && first-history>=1 && last<=numel(wave);
        core=[]; h=[];
        if available, core=wave(first:last); h=wave(first-history:first-1); end
        f=v6_clip_validity_features(core,cfg,e);
        history_status='not_applicable'; history_reasons='none'; history_fault=false;
        boundary_free=true;
        if history>0
            qh=inspect_waveform_quality_v3(h,cfg.target_fs,cfg,history);
            history_status=qh.status; history_reasons=qh.reasons;
            history_fault=ismember(qh.status,{'REJECT','ERROR'});
            D=front.delay_output_samples;
            boundary_free=available && first-history>D && last<=numel(wave)-D;
        end
        blocked=~available || f.hard_fault || history_fault || ~boundary_free;
        if history==0
            % Current noise generation has no constant/dropout quality gate.
            blocked=~available || ~isfinite(f.raw_rms) || f.raw_rms<=0;
        end
        reason=f.qc_reasons;
        if ~isempty(error_reason), reason=error_reason;
        elseif ~available, reason='UNAVAILABLE_SOURCE_SPAN'; end
        row=struct('clip_id',sprintf('Q%06d',numel(items)+1), ...
            'class_name',rec.class_name,'recording_key',rec.key,'recording_index',r, ...
            'raw_path',rec.path,'segment_file',rows{j,5},'core_start_sample',first, ...
            'core_stop_sample',last,'history_samples',history,'available',available, ...
            'partition','','sample_group','none','baseline_blocked',blocked, ...
            'history_status',history_status,'history_reasons',history_reasons, ...
            'resampler_boundary_free',boundary_free);
        f.qc_reasons=reason;
        names=fieldnames(f);
        for n=1:numel(names), row.(names{n})=f.(names{n}); end
        if isempty(items), items=row; else, items(end+1)=row; end %#ok<AGROW>
    end
    group=first_item:numel(items); levels=[items(group).raw_rms]; positive=levels(isfinite(levels) & levels>0);
    if ~isempty(positive)
        reference=median(positive);
        for index=group, items(index).relative_recording_db=20*log10(items(index).raw_rms/reference); end
    end
end

% Fix recording membership BEFORE selecting the clips for manual labeling.
for c=1:numel(e.class_names)
    group=find(strcmp({items.class_name},e.class_names{c}));
    recs=unique([items(group).recording_index]); recs=recs(randperm(numel(recs)));
    nc=max(1,min(numel(recs)-1,round(e.calibration_recording_fraction*numel(recs))));
    calibration=recs(1:nc);
    for index=group
        if ismember(items(index).recording_index,calibration), items(index).partition='calibration';
        else, items(index).partition='holdout'; end
    end
    for partition={'calibration','holdout'}
        pool=group(strcmp({items(group).partition},partition{1}));
        fraction=e.calibration_recording_fraction;
        nr=round(e.random_labels_per_class(c)*fraction);
        ns=round(e.stress_labels_per_class(c)*fraction);
        if strcmp(partition{1},'holdout')
            nr=e.random_labels_per_class(c)-nr; ns=e.stress_labels_per_class(c)-ns;
        end
        random=balanced_draw(items,pool,nr);
        for index=random, items(index).sample_group='random'; end
        remaining=setdiff(pool,random,'stable');
        stress=stress_draw(items,remaining,ns);
        for index=stress, items(index).sample_group='stress'; end
    end
end
selected=find(~strcmp({items.sample_group},'none'));
review_order=selected(randperm(numel(selected)));
save(fullfile(out,'EXPERIMENT.mat'),'cfg','e','items','records','review_order','-v7');
v6_json(fullfile(out,'EXPERIMENT.json'),e);
v6_write_structs(fullfile(out,'FEATURES.tsv'),items);
v6_write_structs(fullfile(out,'REVIEW_MANIFEST.tsv'),items(review_order));
labels=cell(numel(review_order),4);
for j=1:numel(review_order), labels(j,:)={items(review_order(j)).clip_id,'pending','',''}; end
v6_write_tsv(fullfile(out,'LABELS.tsv'),{'clip_id','label','reason','note'},labels);

% Decode each selected recording once more; do not retain whole recordings on disk.
for r=unique([items(selected).recording_index])
    [wave,~,~]=load_recording(records(r).path,cfg);
    group=selected([items(selected).recording_index]==r);
    for index=group
        item=items(index); x=[]; preview_gain=NaN;
        if item.available
            x=wave(item.core_start_sample-item.history_samples:item.core_stop_sample);
            core=x(item.history_samples+1:end);
            if all(isfinite(core)) && any(core~=0)
                preview_gain=0.8/max(abs(core));
                audiowrite(fullfile(out,'review',[item.clip_id '.wav']), ...
                    single(core*preview_gain),cfg.target_fs,'BitsPerSample',32);
            end
        end
        fs=cfg.target_fs;
        save(fullfile(out,'review',[item.clip_id '.mat']),'x','fs','item','preview_gain','-v7');
    end
end
write_counts(out,items,e);
fprintf('\nPrepared %d clips; %d for labeling. No Bellhop or production filtering ran.\n',numel(items),numel(selected));
fprintf('Next: review_clip_validity_v6(out)\nThen: experiment_clip_validity_v6(''analyze'',out)\n%s\n',out);
end

function records=source_recordings(cfg,manifest)
records=struct('class_name',{},'key',{},'path',{},'rows',{});
for c=1:numel(cfg.class_names)
    name=cfg.class_names{c}; files=dir(fullfile(cfg.raw_root,name,'**','*.wav'));
    lookup=containers.Map('KeyType','char','ValueType','char');
    for j=1:numel(files)
        [~,parent]=fileparts(files(j).folder); [~,stem]=fileparts(files(j).name);
        key=lower([parent '/' stem]);
        assert(~isKey(lookup,key),'Ambiguous raw recording: %s/%s',name,key);
        lookup(key)=fullfile(files(j).folder,files(j).name);
    end
    rows=manifest(strcmp(manifest(:,2),name),:); keys=unique(lower(string(rows(:,4))));
    for j=1:numel(keys)
        key=char(keys(j));
        records(end+1)=struct('class_name',name,'key',[name '/' key], ...
            'path',lookup(key),'rows',{rows(strcmpi(rows(:,4),key),:)}); %#ok<AGROW>
    end
end
for j=1:numel(cfg.shipsear_files.Train)
    file=cfg.shipsear_files.Train{j};
    records(end+1)=struct('class_name','noise','key',['noise/' file], ...
        'path',fullfile(cfg.shipsear_root,file),'rows',{cell(0,6)}); %#ok<AGROW>
end
end

function [x,front,reason]=load_recording(path,cfg)
x=[]; reason=''; front=struct('delay_output_samples',0);
try
    [raw,fs]=audioread(path);
catch err
    reason=['DECODE_FAILED:' err.identifier]; return;
end
if isempty(raw) || any(~isfinite(raw(:)))
    reason='EMPTY_OR_NONFINITE_RECORDING'; return;
end
[x,front]=v6_prepare_recording(raw,fs,cfg);
end

function selected=balanced_draw(items,pool,count)
selected=[]; recs=unique([items(pool).recording_index]);
while numel(selected)<count && ~isempty(pool)
    recs=recs(randperm(numel(recs)));
    for r=recs
        group=pool([items(pool).recording_index]==r);
        if isempty(group), continue; end
        index=group(randi(numel(group))); selected(end+1)=index; %#ok<AGROW>
        pool(pool==index)=[];
        if numel(selected)==count, break; end
    end
end
end

function selected=stress_draw(items,pool,count)
selected=[]; if isempty(pool), return; end
fields={'raw_rms_dbfs','relative_recording_db','near_zero_s','transient_fraction', ...
    'flat_peak_ms','low_frame_fraction','spectral_flatness','peak_prominence_db'};
queues=cell(1,numel(fields)+1);
flag=[items(pool).baseline_blocked] | [items(pool).hard_fault] | strcmp({items(pool).qc_status},'REVIEW') | ...
    strcmp({items(pool).history_status},'REVIEW');
queues{1}=pool(flag); queues{1}=queues{1}(randperm(numel(queues{1})));
for f=1:numel(fields)
    values=[items(pool).(fields{f})]; keep=isfinite(values); group=pool(keep); values=values(keep);
    direction='descend'; if ismember(f,[1 2 8]), direction='ascend'; end
    [~,order]=sort(values,direction); queues{f+1}=group(order);
end
while numel(selected)<count
    added=false;
    for q=1:numel(queues)
        queue=queues{q}; queue=queue(~ismember(queue,selected));
        if isempty(queue), continue; end
        selected(end+1)=queue(1); queues{q}=queue(2:end); added=true; %#ok<AGROW>
        if numel(selected)==count, break; end
    end
    if ~added, break; end
end
end

function write_counts(out,items,e)
rows=cell(0,7); normalization=cell(0,9);
for c=1:numel(e.class_names)
    normalized=strcmp({items.class_name},e.class_names{c}) & isfinite([items.normalized_rms]);
    r=[items(normalized).raw_rms]; nr=[items(normalized).normalized_rms];
    values=nan(1,6);
    if ~isempty(r)
        values=[min(r) max(r) min(nr) max(nr) ...
            max(abs([items(normalized).spectral_flatness]-[items(normalized).normalized_flatness])) ...
            max(abs([items(normalized).transient_fraction]-[items(normalized).normalized_transient_fraction]))];
    end
    normalization(end+1,:)=[{e.class_names{c},nnz(normalized)} num2cell(values) ...
        {nnz(normalized & [items.low_frame_fraction]~=[items.normalized_low_frame_fraction])}]; %#ok<AGROW>
    for partition={'calibration','holdout'}
        group=strcmp({items.class_name},e.class_names{c}) & strcmp({items.partition},partition{1});
        rows(end+1,:)={e.class_names{c},partition{1},nnz(group), ...
            numel(unique([items(group).recording_index])), ...
            nnz(group & strcmp({items.sample_group},'random')), ...
            nnz(group & strcmp({items.sample_group},'stress')), ...
            nnz(group & [items.baseline_blocked])}; %#ok<AGROW>
    end
end
v6_write_tsv(fullfile(out,'SAMPLE_COUNTS.tsv'), ...
    {'class_name','partition','inventory_clips','recordings','random_labels','stress_labels','baseline_blocked'},rows);
v6_write_tsv(fullfile(out,'NORMALIZATION_SUMMARY.tsv'), ...
    {'class_name','measured_normalized_clips','raw_rms_min','raw_rms_max','normalized_rms_min','normalized_rms_max', ...
    'max_flatness_absolute_change','max_transient_fraction_absolute_change','low_frame_fraction_changed_clips'},normalization);
end
