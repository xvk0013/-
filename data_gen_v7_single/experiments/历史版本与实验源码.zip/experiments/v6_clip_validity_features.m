function f=v6_clip_validity_features(x,cfg,e)
% Measurements before normalization; flags are observations, not new gates.
q=inspect_waveform_quality_v3(x,cfg.target_fs,cfg,numel(x));
f=struct('hard_fault',ismember(q.status,{'REJECT','ERROR'}), ...
    'qc_status',q.status,'qc_reasons',q.reasons,'raw_peak',q.peak, ...
    'raw_rms',NaN,'raw_rms_dbfs',NaN,'normalization_gain_db',NaN, ...
    'normalized_rms',NaN,'relative_recording_db',NaN, ...
    'near_zero_s',q.near_zero_s,'flat_peak_ms',1000*q.flat_peak_samples/cfg.target_fs, ...
    'transient_fraction',q.transient_fraction, ...
    'low_frame_fraction',NaN,'longest_low_frame_s',NaN, ...
    'spectral_flatness',NaN,'peak_prominence_db',NaN,'peak_persistence',NaN, ...
    'normalized_flatness',NaN,'normalized_transient_fraction',NaN, ...
    'normalized_low_frame_fraction',NaN);
if isempty(x) || any(~isfinite(x)), return; end
x=double(x(:)); f.raw_peak=max(abs(x)); f.raw_rms=sqrt(mean(x.^2));
f.raw_rms_dbfs=20*log10(f.raw_rms);
if f.hard_fault, return; end
[normalized,n]=v6_normalize_input(x,0,cfg);
f.normalization_gain_db=20*log10(n.input_gain); f.normalized_rms=n.input_rms_after;
a=shape(x,cfg.target_fs,e); b=shape(normalized,cfg.target_fs,e);
names=fieldnames(a);
for k=1:numel(names), f.(names{k})=a.(names{k}); end
f.normalized_flatness=b.spectral_flatness;
f.normalized_transient_fraction=b.transient_fraction;
f.normalized_low_frame_fraction=b.low_frame_fraction;
end

function a=shape(x,fs,e)
width=round(e.energy_window_s*fs); hop=round(e.energy_hop_s*fs);
starts=1:hop:numel(x)-width+1;
power=mean(x(starts+(0:width-1)').^2,1);
low=power<=max(power)*10^(e.low_frame_relative_db/10);
d=diff([false low false]); lengths=find(d==-1)-find(d==1);
longest=0;
if ~isempty(lengths), longest=(width+(max(lengths)-1)*hop)/fs; end
impulse=round(e.transient_window_s*fs);
concentration=max(movsum(x.^2,[0 impulse-1],'Endpoints','shrink'))/sum(x.^2);
w=hann(e.spectral_window_samples,'periodic');
S=spectrogram(x,w,e.spectral_window_samples-e.spectral_hop_samples, ...
    e.spectral_window_samples,fs);
P=abs(S(2:end,:)).^2; % Positive frequencies through Nyquist; exclude DC.
P=P(:,sum(P,1)>0); p=P./sum(P,1);
flatness=exp(mean(log(max(p,realmin)),1))./mean(p,1);
[peak,bin]=max(p,[],1);
prominence=10*log10(peak./max(median(p,1),realmin));
dominant=mode(bin);
a=struct('transient_fraction',concentration,'low_frame_fraction',mean(low), ...
    'longest_low_frame_s',longest,'spectral_flatness',median(flatness), ...
    'peak_prominence_db',median(prominence), ...
    'peak_persistence',mean(abs(bin-dominant)<=1));
end
