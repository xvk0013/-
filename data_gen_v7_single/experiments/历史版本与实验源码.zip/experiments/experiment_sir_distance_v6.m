function out=experiment_sir_distance_v6(run_id,acoustics_run_id)
% Invert Bellhop response for source separation; numerical execution is user-run.
% Retains the historical envelope diagnostic; it is not the production recipe.
% Optional second argument reuses reciprocal ARR/channels from this revision.
addpath(fullfile(fileparts(fileparts(mfilename('fullpath'))),'src'),'-begin');
if nargin<1 || isempty(run_id), run_id=char(datetime('now','Format','yyyyMMdd_HHmmss_SSS')); end
if nargin<2, acoustics_run_id=''; end
cfg=cargo_v6_config(run_id,'Train');

% Distances are horizontal, on the same azimuth and same side of the receiver.
experiment.ranges_m=1000:100:4000;
experiment.source1_ranges_m=1000;          % user-specified fixed source 1
experiment.pairs_per_combination=100;
experiment.geometry='2D_same_azimuth_same_receiver_side';
experiment.geometry_method=cfg.geometry_method;
experiment.sir_definition='stronger_over_weaker_on_overlap';
experiment.sir_lower_db=0;
experiment.sir_upper_db=5;
experiment.solution_target_db=(experiment.sir_lower_db+experiment.sir_upper_db)/2;
experiment.success_rule='every_evaluated_pair_strictly_inside_bounds';
experiment.seed=48;
experiment.input_normalization=cfg.normalization;
experiment.acoustics_run_id=acoustics_run_id;

out=fullfile(cfg.data_root,'data_gen_v6_sir_experiment',run_id);
assert(~exist(out,'dir'),'Use a fresh experiment run ID: %s',out);
cfg.run_root=out; cfg.output_root=fullfile(out,'analysis');
cfg.arr_path=fullfile(out,'arr'); cfg.ranges_km=experiment.ranges_m/1000;
[~,cfg.arr_signature]=v6_acoustic_assets(cfg);
cfg.protocol_path=fullfile(cfg.output_root,'PROTOCOL.json');
if ~isempty(acoustics_run_id)
    previous_run=fullfile(cfg.data_root,'data_gen_v6_sir_experiment',acoustics_run_id);
    cfg.arr_path=fullfile(previous_run,'arr');
end
v6_prepare_source_split(cfg);
plan=v6_preflight(cfg,false);
mkdir(out); v6_json(fullfile(out,'EXPERIMENT.json'),experiment);
if isempty(acoustics_run_id), v6_generate_arr(cfg); end
mkdir(cfg.output_root); v6_json(cfg.protocol_path,cfg);
if isempty(acoustics_run_id)
    [channels,geometry]=v6_build_channels(cfg,plan);
else
    previous_analysis=fullfile(previous_run,'analysis');
    saved=load(fullfile(previous_analysis,'CHANNELS.mat'),'channels','geometry');
    channels=saved.channels; geometry=saved.geometry;
    assert(isequal(geometry.ranges_km,cfg.ranges_km) && ...
        isequal(geometry.source_depths_m,cfg.source_depths_m) && ...
        strcmp(geometry.method,cfg.geometry_method) && ...
        geometry.receiver_x_km==cfg.receiver_x_km && ...
        geometry.receiver_depth_m==cfg.receiver_depth_m,'Reused channel geometry differs from this experiment.');
    copyfile(fullfile(previous_analysis,'CHANNELS.mat'),fullfile(cfg.output_root,'CHANNELS.mat'));
    copyfile(fullfile(previous_analysis,'CHANNEL_SUPPORT.tsv'),fullfile(cfg.output_root,'CHANNEL_SUPPORT.tsv'));
    fprintf('Reusing ARR and channels from %s; continuing with source preparation.\n',acoustics_run_id);
end
[sources,recordings]=v6_prepare_sources(cfg,plan);
save(fullfile(out,'INPUTS.mat'),'experiment','cfg','geometry','sources','recordings','-v7');

ranges=experiment.ranges_m; anchors=experiment.source1_ranges_m;
nr=numel(ranges); na=numel(anchors); nd=numel(cfg.source_depths_m);
[~,anchor_rows]=ismember(anchors,ranges);
geometry_indices=reshape(1:numel(channels),nr,nd);
source1_geometry_indices=reshape(geometry_indices(anchor_rows,:),[],1);
source1_channels=channels(source1_geometry_indices);
[r_index,d_index]=ndgrid(1:nr,1:nd);
geometry_rows=num2cell([(1:numel(channels)).' reshape(ranges(r_index(:)),[],1) ...
    reshape(cfg.source_depths_m(d_index(:)),[],1)]);
v6_write_tsv(fullfile(out,'GEOMETRY.tsv'), ...
    {'geometry_index','range_m','source_depth_m'},geometry_rows);

pairs={[1 2],[1 3],[2 3]}; pair_names={'Cargo_Tanker','Cargo_Tug','Tanker_Tug'};
old_rng=rng; restore_rng=onCleanup(@() rng(old_rng));
N=cfg.target_fs*cfg.segment_len_s; P=cfg.target_fs*cfg.source_history_s;
minimum_sir=inf(na,nr); maximum_sir=-inf(na,nr); failures=zeros(na,nr);
trials=experiment.pairs_per_combination;
interval_header={'direction','separation_min_m','separation_max_m', ...
    'source2_range_min_m','source2_range_max_m','grid_points','sir_min_db','sir_max_db'};

for combination=1:numel(pairs)
    slots=pairs{combination}; name=pair_names{combination};
    folder=fullfile(out,name); mkdir(folder);
    sir_bellhop=zeros(na*nd,nr*nd,trials); sir_overlap=sir_bellhop;
    input_sir_db=zeros(trials,1); trial_rows=cell(trials,14);
    solution_rows=cell(trials*na*nd*nd,10); solution_count=0;
    interval_rows=cell(0,12);
    for trial=1:trials
        seed=v6_seed(sprintf('SIR_DISTANCE|%s|%d',name,trial),experiment.seed);
        rng(seed,'twister');
        ia=draw_source(recordings,slots(1),cfg); ib=draw_source(recordings,slots(2),cfg);
        a=load(sources(ia).context_path,'x'); b=load(sources(ib).context_path,'x');
        [envelopes,~]=v6_envelopes(N,cfg.target_fs,2,cfg.solo_range_s,cfg.fade_range_s);
        overlap=all(envelopes>0,2);
        input_rms1=sqrt(mean(a.x(P+(1:N)).^2));
        input_rms2=sqrt(mean(b.x(P+(1:N)).^2));
        input_sir_db(trial)=20*log10(input_rms1/input_rms2);
        [a_full,a_overlap]=received_energy(a.x,source1_channels,P,N,envelopes(:,1),overlap);
        [b_full,b_overlap]=received_energy(b.x,channels,P,N,envelopes(:,2),overlap);
        sir_bellhop(:,:,trial)=10*log10(a_full./b_full.');
        sir_overlap(:,:,trial)=10*log10(a_overlap./b_overlap.');
        assert(all(isfinite(sir_overlap(:,:,trial)),'all') && ...
            all(isfinite(sir_bellhop(:,:,trial)),'all'),'Invalid SIR in trial %d.',trial);
        support=find(overlap);
        trial_rows(trial,:)={trial,seed,ia,ib,sources(ia).row{4},sources(ib).row{4}, ...
            sources(ia).row{5},sources(ib).row{5},input_sir_db(trial), ...
            (support(1)-1)/cfg.target_fs,support(end)/cfg.target_fs,nnz(overlap)/cfg.target_fs,input_rms1,input_rms2};

        % For this exact audio pair, fix source 1 and move only source 2.
        for da=1:nd
            for db=1:nd
                second=(db-1)*nr+(1:nr);
                for ra=1:na
                    first=(da-1)*na+ra; baseline=anchors(ra);
                    signed_curve=sir_overlap(first,second,trial);
                    curve=abs(signed_curve);
                    good=curve>experiment.sir_lower_db & curve<experiment.sir_upper_db;
                    local=separation_intervals(good,curve,curve,baseline,ranges);
                    for j=1:size(local,1)
                        interval_rows(end+1,:)=[{trial,cfg.source_depths_m(da), ...
                            cfg.source_depths_m(db),baseline} local(j,:)]; %#ok<AGROW>
                    end
                    solution_count=solution_count+1;
                    candidates=find(good);
                    if isempty(candidates)
                        solution_rows(solution_count,:)={trial,cfg.source_depths_m(da), ...
                            cfg.source_depths_m(db),baseline,false,NaN,NaN,NaN,NaN,NaN};
                    else
                        % Choose an actually simulated solution closest to the band midpoint.
                        [~,best]=min(abs(curve(candidates)-experiment.solution_target_db));
                        chosen=candidates(best);
                        stronger=1; if signed_curve(chosen)<0, stronger=2; end
                        solution_rows(solution_count,:)={trial,cfg.source_depths_m(da), ...
                            cfg.source_depths_m(db),baseline,true,ranges(chosen), ...
                            ranges(chosen)-baseline,abs(ranges(chosen)-baseline),curve(chosen),stronger};
                    end
                end
            end
        end
        fprintf('%s: inverted source separation for audio pair %d/%d.\n',name,trial,trials);
    end
    v6_write_tsv(fullfile(folder,'TRIALS.tsv'), ...
        {'trial','seed','source1_index','source2_index','recording1','recording2', ...
        'segment1','segment2','input_5s_sir_db','overlap_start_s','overlap_end_s','overlap_duration_s', ...
        'input_rms1','input_rms2'},trial_rows);
    v6_write_tsv(fullfile(folder,'PAIR_SOLUTIONS.tsv'), ...
        {'trial','source1_depth_m','source2_depth_m','source1_range_m','solution_found', ...
        'source2_range_m','signed_offset_m','separation_m','sir_db','stronger_source'},solution_rows);
    v6_write_tsv(fullfile(folder,'PAIR_SEPARATION_INTERVALS.tsv'), ...
        [{'trial','source1_depth_m','source2_depth_m','source1_range_m'} interval_header],interval_rows);
    save(fullfile(folder,'SIR_SAMPLES.mat'),'sir_bellhop','sir_overlap','input_sir_db', ...
        'source1_geometry_indices','experiment','-v7');
    % An aggregate position is allowed only if EVERY measured pair/depth passes.
    for da=1:nd
        for db=1:nd
            first=(da-1)*na+(1:na); second=(db-1)*nr+(1:nr);
            values=abs(sir_overlap(first,second,:));
            minimum_sir=min(minimum_sir,min(values,[],3));
            maximum_sir=max(maximum_sir,max(values,[],3));
            failures=failures+sum(values<=experiment.sir_lower_db | values>=experiment.sir_upper_db,3);
        end
    end
end

cases_per_position=trials*numel(pairs)*nd*nd;
rows=cell(na*nr,8); k=0; baseline_intervals=cell(0,9);
for ra=1:na
    for rb=1:nr
        k=k+1;
        rows(k,:)={anchors(ra),ranges(rb),abs(ranges(rb)-anchors(ra)), ...
            minimum_sir(ra,rb),maximum_sir(ra,rb),cases_per_position,failures(ra,rb),failures(ra,rb)==0};
    end
    local=separation_intervals(failures(ra,:)==0,minimum_sir(ra,:),maximum_sir(ra,:),anchors(ra),ranges);
    for j=1:size(local,1)
        baseline_intervals(end+1,:)=[{anchors(ra)} local(j,:)]; %#ok<AGROW>
    end
end
v6_write_tsv(fullfile(out,'BASELINE_SEPARATIONS.tsv'), ...
    {'source1_range_m','source2_range_m','separation_m','sir_min_db','sir_max_db', ...
    'tested_cases','failed_cases','all_tested_cases_pass'},rows);
v6_write_tsv(fullfile(out,'BASELINE_SEPARATION_INTERVALS.tsv'), ...
    [{'source1_range_m'} interval_header],baseline_intervals);

% Ask whether one separation works for every tested pair/depth at the fixed source 1.
step=diff(ranges(1:2)); separations=0:step:(ranges(end)-ranges(1));
distance_matrix=abs(ranges-anchors.');
common_rows=cell(numel(separations),9); common_good=false(size(separations));
for j=1:numel(separations)
    positions=distance_matrix==separations(j);
    covered=nnz(any(positions,2)); position_count=nnz(positions);
    failed=sum(failures(positions));
    common_good(j)=covered==na && failed==0;
    common_rows(j,:)={separations(j),covered,na,position_count, ...
        position_count*cases_per_position,failed,min(minimum_sir(positions)), ...
        max(maximum_sir(positions)),common_good(j)};
end
v6_write_tsv(fullfile(out,'COMMON_SEPARATION_POINTS.tsv'), ...
    {'separation_m','covered_baselines','required_baselines','position_pairs','tested_cases', ...
    'failed_cases','sir_min_db','sir_max_db','common_separation_found'},common_rows);
spans=grid_intervals(common_good); bounds=cell(size(spans,1),6);
for j=1:size(spans,1)
    lo=spans(j,1); hi=spans(j,2);
    bounds(j,:)={separations(lo),separations(hi),step,hi-lo+1, ...
        min(cell2mat(common_rows(lo:hi,7))),max(cell2mat(common_rows(lo:hi,8)))};
end
v6_write_tsv(fullfile(out,'COMMON_SEPARATION_INTERVALS.tsv'), ...
    {'separation_min_m','separation_max_m','step_m','grid_points','sir_min_db','sir_max_db'},bounds);

f=figure('Visible','off','Position',[100 100 1000 760]);
tiledlayout(ceil(na/2),min(na,2));
for ra=1:na
    nexttile;
    plot(ranges-anchors(ra),minimum_sir(ra,:),'b.', ...
        ranges-anchors(ra),maximum_sir(ra,:),'r.'); hold on;
    yline(experiment.sir_upper_db,'k--','HandleVisibility','off');
    yline(experiment.sir_lower_db,'k:','HandleVisibility','off');
    xlabel('Source 2 offset from source 1 (m)'); ylabel('Strong/weak SIR (dB)');
    title(sprintf('Source 1 at %g m from receiver',anchors(ra)));
    legend('Minimum across tested pairs/depths','Maximum across tested pairs/depths','Location','best');
end
exportgraphics(f,fullfile(out,'SIR_VS_SEPARATION.png'),'Resolution',180); close(f);
if isempty(bounds)
    fprintf('No fixed separation satisfies EVERY tested condition at the fixed source 1.\n');
    fprintf('Use the exact per-audio-pair separation and measured SIR in PAIR_SOLUTIONS.tsv.\n');
else
    fprintf('Common source separation intervals (metres, simulated grid only):\n');
    disp(cell2table(bounds,'VariableNames', ...
        {'separation_min_m','separation_max_m','step_m','grid_points','sir_min_db','sir_max_db'}));
end
fprintf('Experiment complete. No post-propagation gain was used.\n%s\n',out);
end

function index=draw_source(recordings,slot,cfg)
group=find([recordings.class_id]==cfg.class_ids(slot));
recording=group(randi(numel(group)));
clips=recordings(recording).source_indices;
index=clips(randi(numel(clips)));
end

function [full_energy,overlap_energy]=received_energy(x,channels,P,N,envelope,overlap)
full_energy=zeros(numel(channels),1); overlap_energy=full_energy;
for g=1:numel(channels)
    y=apply_continuous_channel_v3(x,channels{g},P,N);
    full_energy(g)=sum(y.^2);
    overlap_energy(g)=sum((y(overlap).*envelope(overlap)).^2);
end
end

function spans=grid_intervals(mask)
edges=diff([false mask(:).' false]);
spans=[find(edges==1).' find(edges==-1).'-1];
end

function rows=separation_intervals(good,low_sir,high_sir,baseline,ranges)
% Keep movement direction and all gaps; an unsigned distance alone loses position.
directions={'toward_receiver','same_range','away_from_receiver'};
masks={ranges<baseline,ranges==baseline,ranges>baseline};
rows=cell(0,8);
for d=1:numel(directions)
    spans=grid_intervals(good & masks{d});
    for j=1:size(spans,1)
        ix=spans(j,1):spans(j,2); separation=abs(ranges(ix)-baseline);
        rows(end+1,:)={directions{d},min(separation),max(separation), ...
            ranges(ix(1)),ranges(ix(end)),numel(ix),min(low_sir(ix)),max(high_sir(ix))}; %#ok<AGROW>
    end
end
end
