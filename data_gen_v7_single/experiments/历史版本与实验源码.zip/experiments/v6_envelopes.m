function [envs,m]=v6_envelopes(N,fs,n_targets,solo_range,fade_range)
envs=ones(N,n_targets);
m=struct('overlap_start_s',0,'overlap_end_s',N/fs,'a_first',1);
if n_targets~=2, return; end

first=1; second=2;
if rand()>=0.5, first=2; second=1; end
m.a_first=(first==1);
solo_head=solo_range(1)+rand()*(solo_range(2)-solo_range(1));
solo_tail=solo_range(1)+rand()*(solo_range(2)-solo_range(1));
fade_A=fade_range(1)+rand()*(fade_range(2)-fade_range(1));
fade_B=fade_range(1)+rand()*(fade_range(2)-fade_range(1));
shape_A=randi(3); shape_B=randi(3);

solo_head_n=round(solo_head*fs); solo_tail_n=round(solo_tail*fs);
fade_A_n=max(round(fade_A*fs),2); fade_B_n=max(round(fade_B*fs),2);
env_A=ones(N,1); env_B=ones(N,1);
fade_out_end=N-solo_tail_n;
fade_out_start=max(fade_out_end-fade_A_n,1);
env_A(fade_out_start:fade_out_end)=1-fade_shape_local(shape_A,fade_out_end-fade_out_start+1);
env_A(fade_out_end:end)=0;
fade_in_start=max(solo_head_n,1);
fade_in_end=min(fade_in_start+fade_B_n,N);
env_B(1:fade_in_start)=0;
env_B(fade_in_start:fade_in_end)=fade_shape_local(shape_B,fade_in_end-fade_in_start+1);
envs(:,first)=env_A; envs(:,second)=env_B;
m.overlap_start_s=solo_head;
m.overlap_end_s=N/fs-solo_tail;
end


function y=fade_shape_local(shape_id,n)
u=linspace(0,1,n)';
switch shape_id
    case 1, y=u;
    case 2, y=0.5-0.5*cos(pi*u);
    case 3, y=(exp(3*u)-1)/(exp(3)-1);
    otherwise, error('未知淡变形状。');
end
end

