function out=experiment_smoke_pairs_v6(run_id,profile)
% 复用一次"建源/建表已完成、双目标组合未完成"运行的 Train 工件，只执行
% 三个双目标组合，分钟级验证排产-阶梯-写盘路径。结果写入原运行的
% dataset 目录；该运行因此不再是完整试点，仅作调试用，通过后用新
% run_id 以默认 profile 生成正式数据。
addpath(fullfile(fileparts(fileparts(mfilename('fullpath'))),'src'),'-begin');
if nargin<2, profile='pilot'; end
run_id=char(run_id);
cfg=cargo_v6_config(run_id,'Train',profile);
run_root=cfg.run_root;
assert(exist(run_root,'dir')==7,'V6:Smoke','Run not found: %s',run_root);
split_root=fullfile(run_root,'splits','Train');
assert(exist(fullfile(split_root,'ENERGY_TABLE.mat'),'file')==2, ...
    'V6:Smoke','Missing splits/Train/ENERGY_TABLE.mat; nothing to reuse.');
S=load(fullfile(split_root,'SOURCES.mat'),'sources','recordings','recording_caps','groups');
C=load(fullfile(run_root,'CHANNELS.mat'),'channels','geometry');
T=load(fullfile(split_root,'ENERGY_TABLE.mat'),'energy');
wave_shape=[numel(S.sources) numel(cfg.ranges_km) numel(cfg.source_depths_m)];
cache=struct('sources',S.sources,'recordings',S.recordings, ...
    'recording_caps',S.recording_caps,'noise_recordings',struct(), ...
    'groups',{S.groups},'channels',{C.channels},'geometry',C.geometry, ...
    'contexts',{cell(numel(S.sources),1)},'context_ticks',zeros(numel(S.sources),1), ...
    'context_count',0,'waves',{cell(wave_shape)},'wave_ticks',zeros(wave_shape), ...
    'wave_count',0,'clock',0,'energy_table',T.energy);
if ~exist(cfg.cache_root,'dir'), [ok,msg]=mkdir(cfg.cache_root); assert(ok,'%s',msg); end
results=cell(1,numel(cfg.combo_slots));
pair_k=find(cellfun(@numel,cfg.combo_slots)==2);
for k=pair_k
    folder=fullfile(cfg.dataset_root,cfg.combo_folders{k},cfg.active_split);
    if exist(folder,'dir')==7
        % 崩溃运行的 catch 分支会向组合目录写入失败报告（TSV/MAT）；
        % 只要没有场景 WAV，整个目录可以安全删除后重跑。
        wavs=dir(fullfile(folder,'**','*.wav'));
        assert(isempty(wavs),'V6:Smoke','Combo folder holds scene WAVs: %s',folder);
        [ok,msg]=rmdir(folder,'s'); assert(ok,'%s',msg);
    end
    fprintf('Smoke: running %s (%d scenes).\n',cfg.combo_names{k},cfg.scene_counts(k));
    [results{k},cache]=v6_run_combo(cfg,cache,k);
    r=results{k};
    fprintf('Smoke %s: accepted %d/%d, attempted %d, primary %d, supplement %d, outside %d, card_mismatch %d.\n', ...
        r.combination,r.accepted,r.requested,r.attempted,r.primary_sir_scenes, ...
        r.supplement_sir_scenes,r.outside_sir_scenes,r.card_band_mismatch_scenes);
end
out=struct('run_id',run_id,'results',{results});
end
