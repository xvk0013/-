function v6_clip_validity_analyze(out)
% Calibrate on Train/calibration recordings; holdout labels never select rules.
addpath(fullfile(fileparts(fileparts(mfilename('fullpath'))),'src'),'-begin');
data=load(fullfile(out,'EXPERIMENT.mat'),'items','e','review_order');
items=data.items; e=data.e; n=numel(items);
[rows,header]=read_tsv_v3(fullfile(out,'LABELS.tsv'),4);
assert(isequal(header,{'clip_id','label','reason','note'}),'Keep the four LABELS.tsv columns.');
[found,index]=ismember(rows(:,1),{items.clip_id});
assert(all(found) && numel(unique(index))==numel(index) && ...
    isequal(sort(index(:)),sort(data.review_order(:))),'Label IDs must match the review sample.');
labels=repmat({'not_sampled'},1,n); reasons=repmat({''},1,n);
values=cellfun(@(x) lower(strtrim(x)),rows(:,2),'UniformOutput',false);
values(cellfun(@isempty,values))={'pending'};
assert(all(ismember(values,{'pending','valid','invalid','uncertain'})), ...
    'Labels must be pending, valid, invalid or uncertain.');
labels(index)=values; reasons(index)=rows(:,3);
reasons=cellfun(@(x) lower(strtrim(x)),reasons,'UniformOutput',false);
reasons(strcmp(labels,'invalid') & cellfun(@isempty,reasons))={'unspecified'};
valid=strcmp(labels,'valid').'; invalid=strcmp(labels,'invalid').';
cal=strcmp({items.partition},'calibration').';
base=[items.baseline_blocked].';
shared=base | [items.hard_fault].';

terms=make_terms(items,cal & (valid | invalid),e);
predictions=apply_terms(items,terms);
[b,b_status]=fit_terms(shared,predictions,terms,1,cal,valid,invalid,e,1);
[c,c_status]=fit_terms(shared,predictions,terms,2:7,cal,valid,invalid,e,e.max_joint_terms);
selected={[],b,c}; names={'A_current','B_level','C_joint'};
flags=[base shared shared];
for m=2:3
    if ~isempty(selected{m}), flags(:,m)=shared | any(predictions(:,selected{m}),2); end
end
rulebook=struct('experiment',e.revision,'status_B',b_status,'status_C',c_status, ...
    'calibration_valid',nnz(cal & valid),'calibration_invalid',nnz(cal & invalid), ...
    'holdout_valid',nnz(~cal & valid),'holdout_invalid',nnz(~cal & invalid), ...
    'pending_labels',nnz(strcmp(labels,'pending')), ...
    'uncertain_labels',nnz(strcmp(labels,'uncertain')), ...
    'max_calibration_valid_false_reject_fraction',e.max_calibration_valid_false_reject_fraction, ...
    'B_terms',terms(b),'C_terms',terms(c), ...
    'B_C_share_core_hard_fault_checks_across_classes',true, ...
    'new_flags_are_review_candidates',true,'production_rules_changed',false);
v6_json(fullfile(out,'RULES.json'),rulebook);
rule_rows=cell(0,9);
for m=2:3
    for t=selected{m}
        p=shared | predictions(:,t);
        rule_rows(end+1,:)={names{m},terms(t).expression,terms(t).kind, ...
            terms(t).threshold1,terms(t).threshold2,terms(t).threshold3, ...
            nnz(cal & valid & p),nnz(cal & invalid & p),terms(t).review_type}; %#ok<AGROW>
    end
end
v6_write_tsv(fullfile(out,'SELECTED_RULES.tsv'), ...
    {'model','expression','kind','threshold1','threshold2','threshold3', ...
    'calibration_valid_flagged_with_fixed_checks','calibration_invalid_flagged_with_fixed_checks','review_type'},rule_rows);

% Separate the balanced random sample from intentionally enriched stress cases.
metrics=cell(0,17); reason_metrics=cell(0,8); classes=[{'all'} e.class_names];
for partition={'calibration','holdout'}
    for cohort={'random','stress','all_labeled'}
        for cl=classes
            group=strcmp({items.partition},partition{1}).';
            if ~strcmp(cohort{1},'all_labeled'), group=group & strcmp({items.sample_group},cohort{1}).'; end
            if ~strcmp(cl{1},'all'), group=group & strcmp({items.class_name},cl{1}).'; end
            nv=nnz(group & valid); ni=nnz(group & invalid);
            for m=1:3
                fp=nnz(group & valid & flags(:,m)); tp=nnz(group & invalid & flags(:,m));
                metrics(end+1,:)={partition{1},cohort{1},cl{1},names{m},nv,ni, ...
                    nnz(group & strcmp(labels,'uncertain').'),nnz(group & strcmp(labels,'pending').'), ...
                    fp,tp,ratio(fp,nv),ratio(tp,ni),ratio(nv-fp,nv), ...
                    numel(unique([items(group & (valid | invalid)).recording_index])), ...
                    nv-fp,ni-tp,nnz(group & ~strcmp(labels,'not_sampled').')}; %#ok<AGROW>
                for why=reshape(unique(reasons(group & invalid)),1,[])
                    subgroup=group & invalid & strcmp(reasons,why{1}).';
                    hits=nnz(subgroup & flags(:,m));
                    reason_metrics(end+1,:)={partition{1},cohort{1},cl{1},names{m}, ...
                        why{1},nnz(subgroup),hits,ratio(hits,nnz(subgroup))}; %#ok<AGROW>
                end
            end
        end
    end
end
v6_write_tsv(fullfile(out,'RULE_COMPARISON.tsv'), ...
    {'partition','cohort','class_name','model','valid_labels','invalid_labels', ...
    'uncertain_labels','pending_labels','valid_flagged','invalid_flagged', ...
    'valid_false_reject_fraction','invalid_recall','valid_retention_fraction', ...
    'labeled_recordings','valid_retained','invalid_missed','review_sample_size'},metrics);
v6_write_tsv(fullfile(out,'INVALID_REASONS.tsv'), ...
    {'partition','cohort','class_name','model','human_reason','invalid_labels','invalid_flagged','recall'},reason_metrics);

coverage=cell(0,9);
for partition={'calibration','holdout'}
    for cl=e.class_names
        group=strcmp({items.partition},partition{1}).' & strcmp({items.class_name},cl{1}).';
        recordings=unique([items(group).recording_index]);
        for m=1:3
            kept=group & ~flags(:,m); kept_records=unique([items(kept).recording_index]);
            coverage(end+1,:)={partition{1},cl{1},names{m},nnz(group),nnz(kept), ...
                numel(recordings),numel(kept_records),nnz(group & flags(:,m)), ...
                numel(setdiff(recordings,kept_records))}; %#ok<AGROW>
        end
    end
end
v6_write_tsv(fullfile(out,'CANDIDATE_COVERAGE.tsv'), ...
    {'partition','class_name','model','inventory_clips','would_retain_clips', ...
    'inventory_recordings','would_retain_recordings','would_flag_clips','would_lose_recordings'},coverage);
decisions=cell(n,11);
for j=1:n
    action='retain'; why='none';
    if base(j), action='existing_block'; why='current_source_availability_or_hard_fault';
    elseif items(j).hard_fault
        action='review_signal_quality'; why=['shared_core_hard_fault:' items(j).qc_reasons];
    elseif flags(j,3)
        matched=c(predictions(j,c)); action='review_signal_quality';
        if any([terms(matched).kind]==7), action='review_content'; end
        why=strjoin({terms(matched).expression},' OR ');
    end
    decisions(j,:)={items(j).clip_id,items(j).class_name,items(j).partition,items(j).sample_group, ...
        labels{j},reasons{j},flags(j,1),flags(j,2),flags(j,3),action,why};
end
v6_write_tsv(fullfile(out,'CANDIDATE_DECISIONS.tsv'), ...
    {'clip_id','class_name','partition','sample_group','human_label','human_reason', ...
    'A_flag','B_flag','C_flag','proposed_action','reason'},decisions);
fprintf('\nValidity analysis: B=%s; C=%s. Pending labels: %d; uncertain: %d.\n', ...
    b_status,c_status,rulebook.pending_labels,rulebook.uncertain_labels);
fprintf('Read holdout/random rows in RULE_COMPARISON.tsv; inspect stress rows separately.\n');
fprintf('New thresholds are review candidates. No production filtering or source deletion ran.\n%s\n',out);
end

function terms=make_terms(items,cal,e)
terms=struct('kind',{},'threshold1',{},'threshold2',{},'threshold3',{},'expression',{},'review_type',{});
if ~any(cal), return; end
level=cut([items(cal).raw_rms_dbfs],e.threshold_quantiles);
for t=level, add(1,t,NaN,NaN,sprintf('raw_rms_dbfs <= %.8g',t),'signal_quality'); end
fields={'near_zero_s','flat_peak_ms','transient_fraction','longest_low_frame_s'};
for k=1:numel(fields)
    for t=cut([items(cal).(fields{k})],e.threshold_quantiles)
        add(k+1,t,NaN,NaN,sprintf('%s >= %.8g',fields{k},t),'signal_quality');
    end
end
for t=level
    for u=cut([items(cal).low_frame_fraction],[0.25 0.5 0.75])
        add(6,t,u,NaN,sprintf('raw_rms_dbfs <= %.8g AND low_frame_fraction >= %.8g',t,u),'signal_quality');
    end
end
ship=cal & ~strcmp({items.class_name},'noise').';
for t=cut([items(ship).relative_recording_db],e.threshold_quantiles)
    for u=cut([items(ship).spectral_flatness],[0.25 0.5 0.75])
        for v=cut([items(ship).peak_prominence_db],[0.25 0.5 0.75])
            add(7,t,u,v,sprintf('vessel AND relative_recording_db <= %.8g AND spectral_flatness >= %.8g AND peak_prominence_db <= %.8g',t,u,v),'content');
        end
    end
end

    function add(kind,t,u,v,expression,review_type)
        terms(end+1)=struct('kind',kind,'threshold1',t,'threshold2',u, ...
            'threshold3',v,'expression',expression,'review_type',review_type);
    end
end

function p=apply_terms(items,terms)
p=false(numel(items),numel(terms));
for j=1:numel(terms)
    t=terms(j);
    switch t.kind
        case 1, flag=[items.raw_rms_dbfs]<=t.threshold1;
        case 2, flag=[items.near_zero_s]>=t.threshold1;
        case 3, flag=[items.flat_peak_ms]>=t.threshold1;
        case 4, flag=[items.transient_fraction]>=t.threshold1;
        case 5, flag=[items.longest_low_frame_s]>=t.threshold1;
        case 6
            flag=[items.raw_rms_dbfs]<=t.threshold1 & [items.low_frame_fraction]>=t.threshold2;
        case 7
            flag=~strcmp({items.class_name},'noise') & [items.relative_recording_db]<=t.threshold1 & ...
                [items.spectral_flatness]>=t.threshold2 & [items.peak_prominence_db]<=t.threshold3;
    end
    p(:,j)=flag(:);
end
end

function [selected,status]=fit_terms(base,p,terms,kinds,cal,valid,invalid,e,max_terms)
selected=[]; cv=cal & valid; ci=cal & invalid;
if ~any(cv) || ~any(ci), status='insufficient_calibration_labels'; return; end
budget=e.max_calibration_valid_false_reject_fraction;
if nnz(base & cv)/nnz(cv)>budget, status='fixed_checks_exceed_valid_false_reject_budget'; return; end
eligible=find(ismember([terms.kind],kinds)); current=base;
for step=1:max_terms
    best=0; best_gain=0; best_fp=inf;
    for j=setdiff(eligible,selected,'stable')
        candidate=current | p(:,j); fp=nnz(candidate & cv);
        if fp/nnz(cv)>budget, continue; end
        gain=nnz(candidate & ci)-nnz(current & ci);
        if gain>best_gain || (gain==best_gain && gain>0 && fp<best_fp)
            best=j; best_gain=gain; best_fp=fp;
        end
    end
    if best==0, break; end
    selected(end+1)=best; current=current | p(:,best); %#ok<AGROW>
end
status='calibrated'; if isempty(selected), status='no_extra_rule_improves_within_budget'; end
end

function values=cut(x,probabilities)
x=sort(x(isfinite(x))); values=[];
if isempty(x), return; end
if numel(x)==1, values=x; return; end
position=1+(numel(x)-1)*probabilities;
values=unique(interp1(1:numel(x),x,position));
values=reshape(values,1,[]);
end

function value=ratio(n,d)
value=NaN; if d>0, value=n/d; end
end
