# data_gen_v6不加噪

更新日期：2026-09-16。当前修订：`data_gen_v6_full_overlap_common_receiver_fixd_v5`。

本版本生成 noise、Cargo、Tanker、Tug 和三种异类双目标组合，覆盖 Train、Test、Val。船舶采用每个有效 5 秒片段等 RMS、独立传播、完整 5 秒直接叠加；noise 使用 ShipsEar 的环境噪声类别和 Fix-D 接收电平。当前流程详见 [数据生成模型V6.md](docs/数据生成模型V6.md)。

## 点击运行

在 MATLAB 中打开根目录的 **`RUN_DATA_GEN_V6.m`**，点击编辑器上的 **“运行”** 即可。默认生成完整 Train、Test、Val，自动设置代码路径、数据根目录并创建新的 run_id；不需要输入命令。

首次运行会根据外部 `DeepShip` 原始录音和项目内 `sources/mapping/0、1、3/segment_mapping.txt` 重建录音级划分，保存到项目内 `sources/split`，随后继续生成。后续运行复用这份清单，不重新抽取划分，也不需要恢复已删除的 denoised 目录。

迁移或调整路径时，修改根目录 `v6_local_config.m`：

- `paths.data_root = 'D:\LSJ\Data'`：外部原始数据根目录，其下包含 DeepShip 和 shipsEar_AUDIOS。
- `paths.output_root`：数据集及每次运行结果位置，默认在数据根目录下的 data_gen_v6_no_noise。
- `paths.bellhop_executable`：默认自动定位项目自带 Windows x64 Bellhop，无需设置 MATLAB 全局 Bellhop 路径。

入口中的 `v6_profile = 'full_dataset'` 表示正式全量；小规模配额改为 `'pilot'`。

输出默认保存在 `D:/LSJ/Data/data_gen_v6_no_noise/<run_id>`，输出路径同时保留在 MATLAB 工作区变量 `v6_output_dir`。每次点击创建新的数据运行目录；声学配置不变时复用项目内 ARR。pilot 共 370 场景、1,480 个 WAV，仍完整建源、建信道和能量表。

**本轮没有运行 MATLAB、Bellhop、生成或测试。旧划分已删除，新清单不保证与旧版一致；旧 denoised 切片检查无法恢复，改由原始音频在归一化前接受现有前史和核心 QC。**

## 文件夹结构

~~~text
RUN_DATA_GEN_V6.m          点击运行的唯一主入口
v6_local_config.m         迁移时集中设置外部数据和输出位置
README.md                 使用说明
数据生成模型v6记忆.md       修订记忆与历史结果
src/                      38 个主线文件；模型配置在 cargo_v6_config.m
acoustics/                环境模板、arr/ 当前资产、legacy_arr/ 历史副本
sources/                  mapping/ 来源映射、split/ 持久录音级清单
tools/bellhop/            项目自带 Windows x64 程序及原许可证
experiments/              8 个可复用实验及辅助函数，主入口不会执行
docs/                     流程说明、实验思路及 V6_INTEGRATION.json
~~~

保留完整记忆、当前流程说明、距离诊断、电平盲消融、配对调试和无效片段实验源码。已放弃的人工标注方案仅作可复用历史材料，不接入主线。主线 ARR 保存在项目内；派生信道、音频缓存和数据集写入配置的输出目录。

此前清理时删除了旧 ARR，这是未按可移植资产保留的整理失误。现已从相邻旧版项目补回 80 个历史 ARR 至 `acoustics/legacy_arr`。**这些副本是旧 4 距离正向几何，不能直接用于当前互易 13 距离主线；当前主线 ARR 尚待用户首次运行生成。**

迁移时完整复制本项目，保留 acoustics、sources、tools；另外准备原始数据，在 `v6_local_config.m` 修改其位置及输出位置，再点击主入口。当前自带程序面向 Windows x64，目标电脑仍需 MATLAB 和 Signal Processing Toolbox。

## 当前主线

1. 首次以种子 47 在各类别内按原始录音约 70%/15%/15% 划分 Train/Test/Val，再按录音轮流选取每类 700/150/150 个有前史的候选片段，保存并复用清单。同一原始录音只进入一个集合。
2. 整条录音平均为单声道、抗混叠重采样到 16 kHz、去除整录音直流。
3. 截取真实 3 秒前史和 5 秒核心，在归一化前检查两者并排除重采样边界不足的候选，PASS/REVIEW 仍按原规则保留。用核心计算增益 `1/sqrt(mean(core.^2))`，整个 8 秒上下文同乘该增益，以 double MAT 保存。各核心等 RMS=1，前史不单独归一化。
4. 在统一海域坐标下独立传播各路，截取受真实前史支持的 5 秒接收窗口。
5. 单目标保留这 5 秒，双目标两路完整重叠、直接相加；**不再施加接收端活动包络、独占段或人工淡入淡出**。两源在每个场景内位置不变，场景之间重新抽取，不模拟航行交汇。
6. 输出增益固定为 1，保存 16 kHz、5 秒、IEEE float32 的 mix/s1/s2/s3；回读通过后提交配额和复用次数。不做逐场景峰值缩放，不做传播后分量配平，不加入 Wenz 或额外背景。

原始 DeepShip 自带背景、设备响应和传播染色仍在模板中；数字等 RMS 不代表真实等声源级。

## 统一海域与 ARR 数量

接收机固定在 **X=0 km、深度 1000 m**；全部船舶位于同侧、同一二维方位剖面，X=1:0.25:4 km，源深 5/10/15 m。保留 `acoustics/template_pos1.bty/.ssp/.brc` 的海底、声速及边界参数，X 直接作为统一海域坐标；射线范围止于现有海底图的 11 km 边界。

采用静止、互易介质中的点源声压互易计算：Bellhop 的计算源放在物理接收机处，计算接收点放在各船舶候选位置。由此获得船舶到同一接收机的信道，**没有把真实船舶移到 1000 m 深处**。互易交换端点不要求对信道做时间反转、共轭或能量归一化。[声学源收互易性](https://sepwww.stanford.edu/sep/prof/fgdp/c9/paper_html/node5.html)

- 频率为 50:100:7950 Hz，共 **80 个 ARR 文件**，前缀 `ReceiverAzi1freq`。
- 每个文件含 13 个距离 × 3 个浅水深度的到达信息。
- 合并 80 个频率后得到 **39 个宽带近似信道**，所有划分和船舶组合共用。
- 1040=80×13 是逐源水平位置分别正向计算的另一种组织方式，当前没有采用。
- 双目标候选中始终排除与另一源相同的水平位置；源深可相同。水平间距为 `abs(X2-X1)`，最小非零值 250 m、最大 3 km。

当前主线 ARR 的持久位置为 `acoustics/arr/<声学配置哈希>/`。哈希由模板内容、几何、频率、生成代码和 Bellhop 程序内容确定，不包含项目绝对位置或 run_id。首次生成，完整后保存完成信息；后续相同配置直接复用。配置改变则创建新子目录，保留旧资产。每次数据运行另外保存 `ARR_PROTOCOL.json` 记录所用声学设置。

坐标写入根目录 `GEOMETRY.tsv`、`CHANNELS.mat` 和场景表。有限射线数等近似下，正反向数值误差尚未量化；当前采用的表述为：**使用当前射线设置、频率网格和 3 秒相对时延窗口构建近似传播信道。**

## 双目标配对与 SIR

能量表保存每个片段在 39 个信道下、完整 5 秒接收参考的 float32 尺度能量。SIR 为两路参考能量之比的绝对 dB 值：

~~~text
E1 = sum(s1.^2)
E2 = sum(s2.^2)
SIR = abs(10*log10(E1/E2))
~~~

每划分、每类组合使用分层目标牌堆：80% 主区 (0,5) dB，20% 补充区 (5,10) dB；牌值分别均匀抽于 0.3～4.7 和 5.3～9.7 dB。守方与计划强源独立随机选择。守方按录音/片段轮转队列抽取，初始距离均匀；攻方按能量表联合选择片段和位置，并倾向少用的录音、片段与位置。

短名单容许值初始 ±2 dB，不足 5 个时每档放宽 1 dB，至多 3 档；没有候选时取最接近目标的合法候选。未落入牌面区间时，L2 更换攻方候选（累计至多 2 次），L3 重抽守方距离并重新查表（至多 1 次），L4 保留合法候选并如实记录 SIR。原 L1 包络重抽已移除，级别编号保留 0/2/3/4。

**80/20 保证的是牌面比例；L4 不保证最终 SIR 全部小于 10 dB，也不保证实际比例恰为 80/20。** 攻方和位置属于按 SIR 条件化的选择，不能声称纯自然随机采样。全窗口宽带 SIR 不保证短时或分频带的掩蔽程度。

每录音、每组合的上限在生成前固定为 `max(10,ceil(2*组合配额/该类可用录音数))`；双目标单片段上限为 `max(2,ceil(2*该录音上限/其可用片段数))`；同一音频对最多成功使用 2 次。不为了填满配额提高上限，容量不足或尝试预算耗尽时报告缺额。

## noise 与 Fix-D

ShipsEar 路径为 `D:/LSJ/Data/shipsEar_AUDIOS`，Train 用录音 81–88、Test 用 89–90、Val 用 91–92，共 8/2/2 个原始录音。沿用录音级划分；同划分内随机 5 秒窗口可重叠复用。

noise 与船舶共用单声道、重采样、整录音去直流和逐片段 RMS=1 的前端。noise 是独立接收端环境录音，不经过 Bellhop，不叠加到船舶样本。

Fix-D 从本次 Train 六种船舶组合的最终 mix 回读 RMS 建立经验分布，每场景贡献一个值，排序后的 log-RMS 保存为根目录 `NOISE_LEVEL_REFERENCE.mat`。三个划分都从这份冻结参考的相邻 log-RMS 值之间连续插值采样电平，只缩放各自 noise 片段；Test/Val 不参与拟合。noise 的 mix 为环境音频，s1/s2/s3 为零，标签 [0,0,0]。

这是接收电平的统计匹配，不是绝对声压标定，也不能消除 DeepShip/ShipsEar 的来源差异。

## 配额和记录

| 组合 | Train | Test | Val |
|---|---:|---:|---:|
| noise | 1386 | 291 | 291 |
| Cargo | 1838 | 394 | 394 |
| Tanker | 1838 | 394 | 394 |
| Tug | 1838 | 394 | 394 |
| Cargo + Tanker | 1530 | 330 | 330 |
| Cargo + Tug | 1530 | 330 | 330 |
| Tanker + Tug | 1530 | 330 | 330 |
| 合计 | 11490 | 2463 | 2463 |

目标合计 16,416 场景、65,664 个 WAV。目录为 `dataset/<noise|0|1|2|0_1|0_2|1_2>/<Train|Test|Val>/<mix|s1|s2|s3>/`，s1/s2/s3 固定对应 Cargo/Tanker/Tug。

- `SCENES.tsv`：来源、归一化增益、物理坐标、实际 SIR、牌面区间、换候选/距离次数、Fix-D 电平。
- `SIR_COUNTS.tsv`：实际主区、补充区、outside 数量；`primary_fraction_actual`、`supplement_fraction_actual` 为实测比例，`primary_fraction_target` 为牌面设计比例；`card_band_mismatch_scenes` 单独统计 L4 未命中牌面区间。
- `PAIR_REUSE.tsv`、`SOURCE_CLIP_USES.tsv`、`SOURCE_REUSE.tsv`：实际复用量和上限。
- `QUOTA_COUNTS.tsv`、`SUMMARY.json`：数量与缺额；`PCM_READBACK.tsv` 保留历史文件名，实际检查 float32 回读和叠加闭包。
- `CHANNEL_SUPPORT.tsv`：因果投影统计，不代表完整射线/频率精度验证。

## 依赖与独立实验

需要目标电脑安装 MATLAB、Signal Processing Toolbox，并提供外部 DeepShip 和 shipsEar_AUDIOS。Bellhop 可执行程序、声学模板和来源映射已包含在项目中，不依赖其他项目文件夹或 MATLAB 全局 Bellhop 包装函数。来源映射只定位原始录音和切片位置，不读取普通切片 WAV 或普通切片 Train/Test/Val 目录。录音级清单和协议自动写入项目 sources/split，并在每次正式运行目录保存清单与协议副本。

无效片段检测目前仅有[新实验讨论方案](docs/无效片段检测实验思路.md)，未接入主线；先前人工标注脚本保留但不启用。

`experiment_sir_distance_v6` 保留第一源 1 km、第二源步长 100 m 的历史包络诊断，数值入口同步使用互易信道；它不是当前生产策略。旧声学工件不能用于新版复用参数，历史结果不能视为当前主线的验证。完整历史记录见记忆文件和 SIR 距离实验说明。

## LB 电平盲消融

`experiments/experiment_level_blind_v6.m` 是独立的数据派生脚本：对一次已完成的生成运行，把每个场景的 `mix/s1/s2/s3` 同乘 `g = target_rms/RMS(mix)`（默认 target_rms=1），镜像写入 `<run_id>_LB`。全局标量不改变谱形、时序与场景内相对电平（SIR 严格保持），只销毁绝对电平。用法：

~~~matlab
cd('experiments'); % 从项目根目录进入
out = experiment_level_blind_v6('<run_id>');
~~~

B 条件就是原始数据集，LB 条件用 `_LB` 目录，文件名与结构完全相同，训练代码只需换数据根路径。在数据侧销毁电平后，任何下游前端在 LB 条件下都无法利用绝对电平，无须检查或改动训练前端。逐场景做写盘回读 ULP 校验与闭包校验（闭包容差 6 ULP：原数据集自身闭包误差与逐路二次舍入叠加）。输出 `LB_MANIFEST.tsv`（逐场景增益与校验）、`LB_SUMMARY.tsv`（各划分×组合的电平分布，兼作论文电平分布图数据）、`LB_PROTOCOL.json`（变换自述）。

训练侧对照协议（2026-09-15 修订）：同种子 ≥3 组，B 与 LB 成对比较。**LB 定位为幅度敏感性对照**：只回答绝对电平贡献了多少；B≈LB 仅豁免电平捷径，不排除来源绑定（DeepShip 与 ShipsEar 的设备/环境差异）等其它捷径，LB 也不代表保留绝对传播电平的现实条件。读数：noise recall（被预测为全零标签的 noise 场景比例）、船舶场景上的 noise 误报率、三类船舶 P/R/F1 与整体准确率；并声明模型前端是否归一化/限幅。
