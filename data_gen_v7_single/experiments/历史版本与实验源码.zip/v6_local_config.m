function paths=v6_local_config()
% 换电脑时只在这里修改原始数据和输出位置；项目内部资源自动相对定位。
root=fileparts(mfilename('fullpath'));
paths.data_root='D:\LSJ\Data';
paths.output_root=fullfile(paths.data_root,'data_gen_v6_no_noise');
paths.bellhop_executable=fullfile(root,'tools','bellhop','bellhop.exe');
end
